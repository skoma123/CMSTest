interface Visibility {
	final static int HIDDEN = 0;
	final static int STEALTH = 1;
	final static int TRANSPARENT = 2;
	final static int SHOW = 3;
}
