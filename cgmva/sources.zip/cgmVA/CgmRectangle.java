/**
 * Rectangle object
 *
 * @author      (C) 1998 Berthold Daum (bdaum@online.de)
 * @version     1.5, 01/10/10
 * @since       CGMView 0.2
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * 14-01-01 bd fixed problem for linewidth > 1
 * 01-10-01 bd fixed problem with negative width/height
 */
class CgmRectangle extends CgmPrimitive {

CgmRectangle (double x1,double y1,double x2,double y2 ) {
//	x = x1;
//	y = y1;
//	Width = x2-x1;
//	Height = y2-y1;
	x = Math.min(x1,x2);
	y = Math.min(y1,y2);
	Height = Math.abs(y2-y1);
	Width = Math.abs(x2-x1);
}
final void draw(java.awt.Graphics g,double w, double h, boolean fill) {

	    int	x1=(int) (x*w+H6);
		int	y1=(int) (y*h+H6);
		int	w1=(int) (Width*w+H6);
		int	h1=(int) (Height*h+H6);
		if ((fill) && (IntStyle >= 1)) {
	 	 	g.setColor(FillColor);
	  		g.fillRect(x1,y1,w1,h1);
	 	} 
	  	if (LineColor != null) {
			int  lw=(int) (LineWidth*w+H5);
	  		g.setColor(LineColor);
			if (lw<=1) {
				g.drawRect(x1,y1,w1,h1);
				return;
			}
			x1 -=lw>>1;
			y1 -=lw>>1;
			w1 +=lw;
			h1 +=lw;
			for(int i=0; i<lw; i++) {
	 		 	g.drawRect(x1++, y1++, w1, h1);
			  	w1 -= 2;
			  	h1 -= 2;
			}
		}
}
final boolean find (double x, double y) {
	return ((visibility != HIDDEN) && (IntStyle >= 1) && (x >= this.x) && (y >= this.y) && (x <= this.x+Width) && ( y <= this.y+Height));
}
}
