/**
 * Disjoint line object
 *
 * @author      (C) 1998 Berthold Daum (bdaum@online.de)
 * @version     1.4, 11/12/98
 * @since       CGMView 0.2
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * 14-01-01 bd some tuning
 */
class CgmDisjtLine extends CgmPrimitivePoly {
CgmDisjtLine (int pnts ) {
	xpoints=new double[pnts];
	ypoints=new double[pnts];
	xpoints1 = new int[pnts];
	ypoints1 = new int[pnts];
	points=pnts;
}
final void draw(java.awt.Graphics g,double w, double h, boolean fill) {
	if (LineColor != null) {
		int i;
		if ((previousW != w) || (previousH != h)) {
			for (i=0;i<points;i++) {
	  			xpoints1[i]=(int) (xpoints[i]*w+H6);
	  			ypoints1[i]=(int) (ypoints[i]*h+H6);
			}
			lw=(int) (LineWidth*w+H5);
			previousW = w;
			previousH = h;
		}
		int p1 = points-1;
		g.setColor(LineColor);
		if (lw<=1) {
			for (i=0;i<p1;i++)
	  			g.drawLine(xpoints1[i],ypoints1[i],
					xpoints1[++i],ypoints1[i]);
	  		return;
		}
		for (i=0;i<p1;i++)
	 		CgmPolygon.drawLine(g,xpoints1[i],ypoints1[i],
				xpoints1[++i],ypoints1[i],lw);
	}	
}
}
