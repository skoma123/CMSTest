/**
 * CGM primitive
 *
 * @author 		(C) 1996 Alexander Larsson (alla@lysator.liu.se)
 * @author      (C) 1998 Berthold Daum (bdaum@online.de)
 * @version     1.4, 14/1/2001
 * @since       CGMView 0.1
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * changes 14-1-2001: added find(String,int). bd
 */

import java.awt.Color;
import java.awt.Graphics;


public abstract class CgmPrimitive implements Visibility {
	static final double H5 = 0.5d;
	static final double H6 = 0.6d;
	double x=0;
	double y=0;
	double Width=0;
	double Height=0;
//	double Angle=0;
	Color LineColor=null;
	Color FillColor=null;
	double LineWidth=0;
	int LineType=0;
	int IntStyle=0;
	int visibility = SHOW;
	boolean noclip=false;
	boolean closed=false;
	Graphics g;

abstract void draw (Graphics g, double w, double h, boolean fill) throws AbstractMethodError;
boolean find (double x, double y) {
	return false;
}
int find (String t, int m) {
	return m;
}
void move(double mx, double my) {
	x += mx;
	y += my;
}
void setClosed() {
	closed = true;
}
}
