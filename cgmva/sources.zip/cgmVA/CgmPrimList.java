/**
 * CGM primitive list
 *  Purpose: By extending the java.util.Vector class we avoid
 *  elementAt(i) calls, which cause considerable synchronization overhead.
 *
 * @author      � 2001 Berthold Daum (bdaum@online.de)
 * @version     1.4, 14/1/2001
 * @since       CGMView 1.4
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
import java.awt.*;

class CgmPrimList extends java.util.Vector implements Visibility {
/**
 * CgmPrimList constructor comment.
 */
public CgmPrimList() {
	super();
}
/**
 * CgmPrimList constructor comment.
 * @param initialCapacity int
 */
public CgmPrimList(int initialCapacity) {
	super(initialCapacity);
}
/**
 * CgmPrimList constructor comment.
 * @param initialCapacity int
 * @param capacityIncrement int
 */
public CgmPrimList(int initialCapacity, int capacityIncrement) {
	super(initialCapacity, capacityIncrement);
}
 final synchronized int find(double px,double py) {
        for (int i = elementCount-1; i>= 0; i--)
            //  for (int i=0;i<elementCount;i++) 
		if (((CgmPrimitive) elementData[i]).find(px,py)) { 
            return i;
        }
  return -1;
 } 
 final synchronized int find(String t,int m) {
  for (int i=0;i<elementCount;i++) 	{
	  	CgmPrimitive p = (CgmPrimitive) elementData[i];
	  	if ((p instanceof CgmText) && (p.find(t,m) == 0)) m = i;
  		}
  return m;
 } 
/**
 * Render a picture.
 * Creation date: (04.01.01 11:24:30)
 */
  final  synchronized void render(Graphics g,double Width,double Height,double cx,double cx2,double cy,double cy2,boolean vis) {
   CgmPrimitive p;
   for (int i=0;i<elementCount;i++) {
  		p = (CgmPrimitive) elementData[i];
  		int v = p.visibility;
  		if ((v > STEALTH) && ((p.noclip) || ((p.x+p.Width >= cx) && (p.x <= cx2) && (p.y+p.Height >= cy) && (p.y <= cy2))))
  		p.draw(g,Width,Height,vis & (v == SHOW));
   		
	}	
 } 
final synchronized int replaceText (int n, String txt )  {
   CgmPrimitive p;
   for (int i=0;i<elementCount;i++) {
  		p = (CgmPrimitive) elementData[i];
  		if ((p instanceof CgmText) && (--n <= 0)) {
			((CgmText) p).Content = txt;
			return -1;
  		}		
	}
  	return n;
 } 
}
