import java.awt.Color;

/**
 * CGM attribute holder
 *
 * @author      (C) 1998-2001 Berthold Daum (bdaum@online.de)
 * @version     1.5,1/10/2001
 * @since       CGMView 0.3
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Changes:
 * 16-11-98: Total redesign, context and picture extend now the same
 *           abstract class, we use polymorphism to set the attributes
 *           of context or picture.
 */

abstract class Cgm extends Object {
  String name="";
  CgmViewApplet applet;
  double  Width;
  double  Height;
  double  ax=1.0,bx=0.0,ay=-1.0,by=0.0;
  int     EdgeWidthMode       = 0;
  int     LineWidthMode       = 0;
  int	  MarkerSizeMode	  = 0;
  boolean EdgesVisible        = false;
  int     EdgeType            = 1;
  int     LineType            = 1;
  int	  MarkerType		  = 3;
  double  EdgeWidth           = 1.0;
  double  LineWidth           = 1.0;
  double  MarkerSize		  = 3.0;
  int     InteriorStyle       = 1;
  int     HatchIndex          = 1;
  Color   FillColor;
  Color   EdgeColor;
  Color   LineColor;
  Color   MarkerColor;
  Color   BackColor;
  Color   TextColor;
  double  CharacterHeight     = 0.015;
  double  CharacterExpansion  = 1.0;
  double  CharacterSpacing    = 0.0;
  int  	  TextPath			  = 0;
  double  CharOri			  = 0;
  double  CharSlant           = 0;
  int     FontIndex           = 1;
  int     TextAlignVert = 0;
  int	  TextAlignHor = 0;

abstract int replaceText (int n, String txt );
  final void vdcExt(double x1,double y1,double x2,double y2) {
  	Width = x2-x1;
  	Height = y2-y1;
  	ax=1.0/Math.max(Width,Height);
  	ay=-ax;
	bx=-ax*x1;
	by=-ay*y2;
  }  
}
