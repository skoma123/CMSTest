/**
 * CGM binary reader
 *
 * @author 		(C) 1996 Alexander Larsson (alla@lysator.liu.se)
 * @author      (C) 1998 Berthold Daum (bdaum@online.de)
 * @version     1.5, 01/10/2001
 * @since       CGMView 0.3
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * 14-01-01 bd added support for floating point vdc's.
 * 14-01-01 bd polygon sets (flags ignored).
 * 01-10-01 bd inverse colors
 */
import java.awt.Color;
import java.io.DataInput;
import java.io.EOFException;
import java.io.IOException;


public class CgmBinReader extends CgmReader implements Runnable {

  int paramlen;

  // Precision stuff:
  int intprec=2;
  int indexprec=2;
  int colorprec=1;
  int colorindexprec=1;
  boolean VdcIsInt=true;
  int vdcrealprec=4;
  int vdcrealtype=16;
  int vdcintprec=2;
  static final int enumprec=2;
  boolean paramContinued=false;
  CgmBinReader(DataInput in, CgmContext cgm) {
	this.in=in;
	this.cgm=cgm;
	this.ContextOrPicture=cgm;
	ReaderThread=new Thread(this,"Reader-thread");
	ReaderThread.start();
  }  
private final byte readByte() throws IOException {
	if (paramlen==0) {
		if (paramContinued) paramlen = readParamLen();
		else return 0;
	}
	paramlen--;
	return in.readByte();
  }  
private final void readClass3(int elid) throws IOException {
	switch (elid) {
case 1:
	  vdcintprec=readPrec();
	  return;
case 2:
	  readInt(enumprec);
	  int a=readInt(intprec);
	  vdcrealtype=readInt(intprec);
	  vdcrealprec = (a+vdcrealtype)>>3;
	  return;
	}
  }  
/**
 * Read color component in binary mode.
 * Creation date: (02.10.2001 10:47:11)
 * @return double
 */
protected double readColorComp() throws java.lang.Exception {
	return readInt(colorprec);
}
  final void readElement() throws IOException{
	int elclass,elid;
	int pad;
	int first;

	try {
	  while (!cgm.FinishedLoading) {
	first=in.readUnsignedShort();
	paramlen=first & 0x1f;
	first>>=5;
	
	elid=first & 0x7f;
	first>>=7;
	
	elclass=first & 0xf;
	
	if (paramlen==31) paramlen=readParamLen();
	pad = paramlen & 1;
//	System.out.println("Token: "+elclass+", "+elid+", "+paramlen);
	switch (elclass) {
	case 0:
	 readMetaFileDelim(elid);
	  break;
	case 1:
	  readMetaFileDescr(elid);
	  break;
	case 2:
	  readMetaFilePictDescr(elid);
	  break;
	case 3:
	  readClass3(elid);
	  break;
	case 4:
	  readGraphicPrimitives(elid);
	  break;
	case 5:
	  readGraphicsAttributes(elid);
//	  break;
//	default:
//	  System.out.println("Unknown class: "+elclass+", "+elid);
	}
	paramlen += pad;
	if (paramlen>0) skip();
	} 
}	
	catch (EOFException e) {
	  if (cgm.currpic!=null)
	  cgm.endMF();
	}
  }                    
private final double readFloat() throws IOException {
	if ((paramContinued) && (paramlen==0)) paramlen = readParamLen();
	if (paramlen >= vdcrealprec) {
		paramlen-=vdcrealprec;
		switch (vdcrealtype) {
case 23:
		return in.readFloat();
case 52:
		return in.readDouble();
case 16:
		return ((double) in.readInt())/0x00010000;
case 32:
		return ((double) (in.readLong()>>8))/0x01000000;
default:
		System.out.println("Unsupported floating point format");
		System.exit(1);
		}
	}
	skip();
	return 0.0;
  }  
private final void readGraphicPrimitives(int elid) throws IOException {
	double x,cx,cy,x1,y1,x2,y2;
	CgmPicture cp=cgm.currpic;
	if (cp == null) 
		{ System.out.println("Unsupported file format");
			System.exit(1);
		}
	switch(elid) {
	case 1:
	  cp.polygon(readPoints(false),false); // polyline
	  return;
	case 2:
	  cp.disjtLine(readPoints(false));  // disjoint polyline
	  return;
	case 3:
	  cp.marker(readPoints(false));  // polymarker
	  return;
	case 4:		// text
	  cp.text(false,0,0,readVdc(),readVdc(),(readInt(enumprec) == 1),readString());
	  return;
	case 5:		// restricted text
	  cp.text(false,readVdc(),readVdc(),readVdc(),readVdc(),(readInt(enumprec) == 1),readString());
	  return;
	case 6:		// append text
	  cp.text(true,0,0,0,0,(readInt(enumprec) == 1),readString());
	  return;
	case 7:
	  cp.polygon(readPoints(false),true); // polygon
	  return;
	case 8:
	  cp.polygon(readPoints(true),true); // polygon set
	  return;
	case 9:		// cell array
	  x1=readVdc(); // 2 corner points
	  y1=readVdc();
	  x2=readVdc();
	  y2=readVdc();
	  readVdc();  // third point
	  readVdc();
	  int cols=readInt(intprec)+1; // number cols
	  int rows=readInt(intprec); // number rows
	  cx=readInt(enumprec); // local color prec
	  readInt(enumprec); // cell color prec
	  readInt(enumprec);  // FIXME Whats that? Undocumented
	  int d = cols*rows;
	  int[] ca = new int[d];
	  for (int i=0; i<d;i++) 
		 	ca[i] = readColor(COLOR_MODE_INDEXED).getRGB();
	  cp.cellArray(x1,y1,x2 ,y2, ca, cols, rows);
	  return;
	case 10: // gdp
	  System.out.println("Generalized Drawing Primitive unsupported (proprietary format)");
	  return;
	case 11:
	  cp.rectangle(readVdc(),readVdc(),readVdc(),readVdc());
	  return;
	case 12:
	  cx=readVdc();
	  cy=readVdc();
	  x=readVdc();
	  cp.ellipse(cx,cy,cx,cy+x,cx+x,cy);
	  return;
	case 13:
	case 14:
	  cp.circarc(readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readType());
	  return;
	case 15:
	case 16:
	  cp.circarc(readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readType());
	  return;
	case 17:
	  cp.ellipse(readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc());
	  return;
	case 18:
	case 19:
	  cp.elliparc(readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readType());
	  return;
	case 21:
	  if (cp.PrimList.size() > 0)
	     ((CgmPrimitive) cp.PrimList.lastElement()).setClosed();
	  return;
//	case 22:
//	  cp.hyparc(readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc());
//	  return;
//	case 23:
//	  cp.pararc(readVdc(),readVdc(),readVdc(),readVdc(),readVdc(),readVdc());
//	  return;
//  case 24:
//    cp.nubspl(readPoints());
//	  return;
	case 26:
	  cp.bezier(readInt(enumprec),readPoints(false));
	  return;
	default:
	  System.out.println("cgmVA: Unsupported Primitive "+elid);
	}
  }    
private final void readGraphicsAttributes(int elid) throws IOException {
	switch(elid) {
	case 2:		
	  ContextOrPicture.LineType=readInt(enumprec);
	  return;	
	case 3:		
	  ContextOrPicture.LineWidth=readVdc();
	  return;	
	case 4:		
	  ContextOrPicture.LineColor=readColor();
	  return;
	case 6:		
	  ContextOrPicture.MarkerType=readInt(enumprec);
	  return;	
	case 7:		
	  ContextOrPicture.MarkerSize=readVdc();
	  return;	
	case 8:		
	  ContextOrPicture.MarkerColor=readColor();
	  return;		
	case 10:
	  ContextOrPicture.FontIndex=Math.max(1,readInt(indexprec));
	case 11:   // ignore text precision
	  return;
	case 12:
	  ContextOrPicture.CharacterExpansion=Math.max(0.5,readVdc());
	  return;
	case 13:
	  ContextOrPicture.CharacterSpacing=readVdc();
	  return;
	case 14:
	  ContextOrPicture.TextColor=readColor();
	  return;
	case 15:		
	  ContextOrPicture.CharacterHeight=Math.abs(readVdc()*ContextOrPicture.ay);
	  return;
	case 16:
	  double a = toAngle(readVdc(),readVdc());
	  double b = toAngle(readVdc(),readVdc());
	  ContextOrPicture.CharOri = b;
	  ContextOrPicture.CharSlant = 1/Math.tan(b-a);
	  return;
	case 17:
	  ContextOrPicture.TextPath=readInt(enumprec);
	  return;
	case 18:	
	  ContextOrPicture.TextAlignHor =  readInt(enumprec);
	  ContextOrPicture.TextAlignVert =  readInt(enumprec);
	  return;
	case 22:
	  ContextOrPicture.InteriorStyle=readInt(enumprec);
	  if (ContextOrPicture.InteriorStyle > 2)
	  	ContextOrPicture.InteriorStyle = 0;
	  return;
	case 23:		
	  ContextOrPicture.FillColor=readColor();
	  return;
	case 24:
	  ContextOrPicture.HatchIndex=readInt(indexprec);
	  break;
	case 30:
	  ContextOrPicture.EdgesVisible=(readInt(enumprec)==1);
	  break;	
	case 28:		
	  ContextOrPicture.EdgeWidth=readVdc();
	  break;	
	case 27:		
	  ContextOrPicture.EdgeType=readInt(enumprec);
	  break;	
	case 29:		
	  ContextOrPicture.EdgeColor=readColor();
	  return;	
	case 34:
	  Color col;
	  int i= readInt(colorindexprec);
	  while (paramlen>0) {
		col=readColor(COLOR_MODE_DIRECT);
	    try { ColorTable[i]=col; }
	    catch (ArrayIndexOutOfBoundsException e) {
	  	  System.out.println("ColorTable out of bounds: "+i);
	 	}
		i++;
	  }
	  ColorMode=COLOR_MODE_INDEXED;
	  return;
	default:
		System.out.println("Unknown attribute: "+elid);
	}
  }            
protected final int readInt() throws Exception {
	return readInt(colorindexprec);
  }            
private final int readInt(int prec) throws IOException {
	if ((paramContinued) && (paramlen==0)) paramlen = readParamLen();
	int p = paramlen;
	if (paramlen > prec) {
		paramlen-=prec;
		p = prec;
	} else {
		paramlen = 0;
	}
	switch (p) {
	case 1:
	  return in.readUnsignedByte();
	case 2:
	  return in.readShort();
	case 3:
	  return in.readShort()<<8+in.readUnsignedByte();
	case 4:
	  return in.readInt();
	default:
	  return 0;
	}
  }        
private final void readMetaFileDelim(int elid) throws IOException {
	switch(elid) {
	case 1:
	  cgm.beginMF(readString(paramlen));
	case 5:
	  ContextOrPicture = cgm;
	  return;
	case 2:
	  cgm.endMF();
	  return;
	case 3:
	  cgm.beginPic(readString(paramlen));
	  ContextOrPicture = cgm.currpic;
	case 0:
	case 4:
	case 8: // rem segment start (V3)
	case 9: // rem segment end
//	  return;
//	default:
//		System.out.println("cgmVA: Unknown delimiter "+elid);
	}
  }      
private final void readMetaFileDescr(int elid) throws IOException {
	int a;
	switch(elid) {
	case 3:
	  VdcIsInt= (readInt(enumprec)==0);
	  return;
	case 4:
	  intprec=readPrec();
	case 1:
	case 5:
	  return;
	case 6:
	  indexprec=readPrec();
	  return;
	case 7:
	  colorprec=readPrec();
	  return;
	case 8:
	  colorindexprec=readPrec();
	  return;
	case 9:
	  if ((a = readInt(enumprec)) > 256) ColorTable=new Color[a+1];
	  return;
	case 10:
	  colr1 = readInt(colorprec);
	  colg1 = readInt(colorprec);
	  colb1 = readInt(colorprec);
	  colr2 = 255/(readInt(colorprec)-colr1);
	  colg2 = 255/(readInt(colorprec)-colg1);
	  colb2 = 255/(readInt(colorprec)-colb1);
	  return;
	case 12:
	  paramlen=0;
	  return;
	case 13:
	  while (paramlen>0) {
		int len=readByte();
		String str=readString(len);
		cgm.addFont(str);
	  }
	  return;
	}
  }  
private final void readMetaFilePictDescr(int elid) throws IOException {
   switch(elid) {
   case 2:
	 switch(readInt(enumprec)) {
	 case 0:
	   ColorMode=COLOR_MODE_INDEXED;
	   return;
	 case 1:
	   ColorMode=COLOR_MODE_DIRECT;
	   return;
	 default:
	   System.out.println("Illegal colour mode");
	   System.exit(1);
	 }
	 return;
   case 3:
	   ContextOrPicture.LineWidthMode=readInt(enumprec);
	   return;
   case 4:
	   ContextOrPicture.MarkerSizeMode=readInt(enumprec);
	   return;
   case 5:
	   ContextOrPicture.EdgeWidthMode=readInt(enumprec);
	   return;
   case 6:
	   ContextOrPicture.vdcExt(readVdc(),readVdc(),readVdc(),readVdc());
//	   ContextOrPicture.vdcExt(readInt(vdcintprec),readInt(vdcintprec),readInt(vdcintprec),readInt(vdcintprec));
	   return;
   case 7:
	   ContextOrPicture.BackColor=readColor(COLOR_MODE_DIRECT);
//	   return;
//   case 17:		// line pattern ?
//     return;
   }
  }    
private final int readParamLen() throws IOException {
	int l = in.readUnsignedShort();
	int l2 = (l & 0x7fff);
	paramContinued = (l != l2);
	return l2;
}
private final double[] readPoints(boolean flags) throws IOException {
	 int i=0;
	 int vdclen = (VdcIsInt) ? vdcintprec : vdcrealprec;
	 if (flags) vdclen += enumprec/2;
	 int numpoints = paramlen/vdclen;
	 double[] points =new double[numpoints];
	 while (paramlen > 0) {
 		while (paramlen > 0) {
	 		points[i++]=readVdc();
	 		points[i++]=readVdc();
	 		if (flags) readInt(enumprec);
 		}
	 	if (paramContinued) {
		 	paramlen = readParamLen();
			numpoints += paramlen/vdclen;
			double[] p =new double[numpoints];
//			for (int k=0;k<i;k++) p[k] = points[k];
			System.arraycopy(points,0,p,0,i);
			points = p;
	 	}
	 }
	 return points;
}
private final int readPrec() throws IOException {
	return (readInt(paramlen)+7)>>3;
  }  
private  final String readString() throws IOException {
  	if (paramlen<1) return "cgmVA: Invalid string";
  	int len = in.readUnsignedByte();
  	paramlen--;
	return readString(len);
  }  
private final String readString(int len) throws IOException {
	if (paramlen<len){
	  System.out.println("Bad string");
	  len = paramlen;
	}
	paramlen-=len;
	byte[] buf = new byte[len];
	in.readFully(buf,0,len);
	return new String(buf);
	
  }    
private final int readType() throws IOException {
	return (paramlen==0) ? -1 : readInt(enumprec);
}
private final double readVdc() throws IOException {
	return (VdcIsInt) ? (double) readInt(vdcintprec) : readFloat();
  }  
private final void skip() throws IOException {
	while (paramlen > 0) {
		in.skipBytes(paramlen);
		if (paramContinued) {
			paramlen = readParamLen();
			return;
		}
		paramlen = 0;
	}
  }  
}
