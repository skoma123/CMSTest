/**
 * CGM Ascii reader
 *
 * @author      (C) 1999 Berthold Daum (bdaum@online.de)
 * @version     1.5, 01/10/2001
 * @since       CGMView 0.3
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * 14-01-01 bd support for polygon set (flags ignored)
 * 01-10-01 bd inverse colors
 *             allowed double quote
 *             fixed problems with TEXTALIGN, etc.
 */
import java.awt.Color;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.util.Vector;


public class CgmAsciiReader extends CgmReader implements Runnable {

StreamTokenizer tokenizer;
NoCrInputStream nin;
boolean isComment = false;
int ctSize = 256;


  CgmAsciiReader(DataInputStream in, CgmContext cgm) {
	this.in=in;
	this.cgm=cgm;
	this.ContextOrPicture=cgm;
	nin = new NoCrInputStream(in); // we do this because the Tokenizer cannot do line feed in quoted strings
	tokenizer = new StreamTokenizer(nin);
	tokenizer.resetSyntax();
	tokenizer.wordChars('a', 'z');
	tokenizer.wordChars('A', 'Z');
	tokenizer.whitespaceChars(0, ' ');
	tokenizer.whitespaceChars('(', ')');
	tokenizer.whitespaceChars(',',',');
	tokenizer.quoteChar('\'');
	tokenizer.quoteChar('"');
	tokenizer.parseNumbers();
	ReaderThread=new Thread(this,"Reader-thread");
	ReaderThread.start();
  }    
private final int nextToken() throws IOException {
int	token = tokenizer.nextToken();
	 while (token == '%') {	
		 readComment();
		 token = tokenizer.nextToken();
	 }
	return token;
}
private final void notifyUnknown(String str) throws IOException {
		System.out.println("Unknown command "+str);
		skip();
}
/**
 * Read color component in ASCII mode.
 * Creation date: (02.10.2001 10:47:11)
 * @return double
 */
protected double readColorComp() throws java.lang.Exception {
	return readFloat();
}
private final void readComment()  throws IOException{
int token;
	do {
	token = tokenizer.nextToken();
	} while (token != '%');
}
final void readElement() throws IOException{
	double cx,cy,x,x1,y1,x2,y2;
	int a;
	try {
	  while (!cgm.FinishedLoading) {
	  	int token = nextToken();
	  	if (token != StreamTokenizer.TT_WORD) {
	  		System.out.println("Command expected, line "+nin.lineno);
	  		System.exit(1); 
	  	}
	  	String cgmCommand = tokenizer.sval.toUpperCase();
	  	try {
	  		switch (cgmCommand.length()) {
/*
	case 3:
		if (cgmCommand.equals("GDP")) {
			break;
		}
		if (cgmCommand.equals("ASF")) {
			break;
		}
		notifyUnknown(cgmCommand);
		break;
*/	
	case 4:
		if (cgmCommand.equals("LINE")) {
	  		cgm.currpic.polygon(readPoints(false),false);
			break;
		}
		if (cgmCommand.equals("TEXT")) {
	 		cgm.currpic.text(false,0,0,readFloat(),readFloat(),(readKeyword("1FINAL",0)==1),readString());
			break;
		}
		if (cgmCommand.equals("RECT")) {
	  		cgm.currpic.rectangle(readFloat(),readFloat(),readFloat(),readFloat());
//			break;
		}
/*
		if (cgmCommand.equals("CLIP")) {
			break;
		}
		notifyUnknown(cgmCommand);
*/
		break;		
	case 5:
		if (cgmCommand.equals("BEGMF")) {
	  		cgm.beginMF(readString());
	  		ContextOrPicture = cgm;
			break;
		}
		if (cgmCommand.equals("ENDMF")) {
			cgm.endMF();
			break;
		}
		notifyUnknown(cgmCommand);
		break;		
	case 6:
		if (cgmCommand.equals("BEGPIC")) {
	  		cgm.beginPic(readString());
	  		ContextOrPicture = cgm.currpic;
			break;
		}
		if (cgmCommand.equals("ENDPIC")) {
			ContextOrPicture = cgm;
			break;
		}
		if (cgmCommand.equals("VDCEXT")) {
	 		ContextOrPicture.vdcExt(readFloat(),readFloat(),readFloat(),readFloat());
			break;
		}
		if (cgmCommand.equals("MARKER")) {
			cgm.currpic.marker(readPoints(false));
			break;
		}
		if (cgmCommand.equals("CIRCLE")) {
	  		cx=readFloat();
	  		cy=readFloat();
	  		x=readFloat();
	  		cgm.currpic.ellipse(cx,cy,cx,cy+x,cx+x,cy);
			break;
		}
		if (cgmCommand.equals("3PT")) {
	  		cgm.currpic.circarc(readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),-1);
			break;
		}
		if (cgmCommand.equals("ARCCTR")) {

	  		cgm.currpic.circarc(readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),-1);
//			break;
		}
/*
		if (cgmCommand.equals("MFDESC")) {
			break;
		}
		if (cgmCommand.equals("ESCAPE")) {
			break;
		}
		notifyUnknown(cgmCommand);
*/
		break;		
	case 7:
		if (cgmCommand.equals("POLYGON")) {
			cgm.currpic.polygon(readPoints(false),true);
			break;
		}
		if (cgmCommand.equals("ELLIPSE")) {
	  		cgm.currpic.ellipse(readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat());
			break;
		}
		if (cgmCommand.equals("CHARORI")) {
	  		cx = toAngle(readFloat(),readFloat());
	  		cy = toAngle(readFloat(),readFloat());
	  		ContextOrPicture.CharOri = cy;
	  		ContextOrPicture.CharSlant = 1/Math.tan(cy-cx);
			break;
		}
		if (cgmCommand.equals("EDGEVIS")) {
   			ContextOrPicture.EdgesVisible=(readKeyword("1ON",0)==1);
//			break;
		}
/*
		if (cgmCommand.equals("PATSIZE")) {
			break;
		}
		if (cgmCommand.equals("MESSAGE")) {
			break;
		}
		if (cgmCommand.equals("VDCTYPE")) {
			break;
		}
		if (cgmCommand.equals("AUXCOLR")) {
			break;
		}
		notifyUnknown(cgmCommand);
*/
		break;		
	case 8:
		if (cgmCommand.equals("LINETYPE")) {
			ContextOrPicture.LineType= readKeyword("1SOLID",0);
			break;
		}
		if (cgmCommand.equals("LINECOLR")) {
			ContextOrPicture.LineColor=readColor();
			break;
		}
		if (cgmCommand.equals("TEXTCOLR")) {
			ContextOrPicture.TextColor=readColor();
			break;
		}
		if (cgmCommand.equals("INTSTYLE")) {
			ContextOrPicture.InteriorStyle = readKeyword("1SOLID2PATTERN3HATCH",0);
			break;
		}
		if (cgmCommand.equals("FILLCOLR")) {
			ContextOrPicture.FillColor=readColor();
			break;
		}
		if (cgmCommand.equals("ELLIPARC")) {
	  		cgm.currpic.elliparc(readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),-1);
			break;
		}
		if (cgmCommand.equals("TEXTPREC")) { // not supported
			break;
		}
		if (cgmCommand.equals("TEXTPATH")) {
			ContextOrPicture.TextPath = readKeyword("0RIGHT1LEFT2UP",3);
			break;
		}
		if (cgmCommand.equals("PATINDEX")) {
			break;
		}
		if (cgmCommand.equals("EDGETYPE")) {
			ContextOrPicture.EdgeType= readKeyword("1SOLID",0);
			break;
		}
		if (cgmCommand.equals("EDGECOLR")) {
			ContextOrPicture.EdgeColor=readColor();
			break;
		}
		if (cgmCommand.equals("APNDTEXT")) {
	 		cgm.currpic.text(true,0,0,0,0,(readKeyword("1FINAL",0)==1),readString());
			break;
		}
		if (cgmCommand.equals("FONTLIST")) 
		{
			while (nextToken() == 39) {
					cgm.addFont(tokenizer.sval);
			}
			break;
		}
		if (cgmCommand.equals("BACKCOLR")) {
			ContextOrPicture.BackColor=readColor(COLOR_MODE_DIRECT);
			break;
		}
		if (cgmCommand.equals("COLRMODE")) {
			ColorMode = readKeyword("2INDEXED",0);
//			break;
		}
/*
		if (cgmCommand.equals("PATTABLE")) {
			break;
		}
		if (cgmCommand.equals("APPLDATA")) {
			break;
		}
		if (cgmCommand.equals("REALPREC")) {
			break;
		}
		if (cgmCommand.equals("COLRPREC")) {
			break;
		}
		if (cgmCommand.equals("CLIPRECT")) {
			break;
		}
		if (cgmCommand.equals("INCRLINE")) {
			break;
		}
		notifyUnknown(cgmCommand);
*/
		break;
	case 9:
		if (cgmCommand.equals("DISJTLINE")) {
			cgm.currpic.disjtLine(readPoints(false));
			break;
		}
		if (cgmCommand.equals("RESTRTEXT")) {
	 		cgm.currpic.text(false,readFloat(),readFloat(),readFloat(),readFloat(),(readKeyword("1FINAL",0)==1),readString());
			break;
		}
		if (cgmCommand.equals("POLGONSET")) {
			cgm.currpic.polygon(readPoints(true),true);
			break;
		}
		if (cgmCommand.equals("CELLARRAY")) {
	  		x1=readFloat(); // 3 corner points
	  		y1=readFloat();
	  		x2=readFloat();
	  		y2=readFloat();
	  		readFloat();
	  		readFloat();
	  		int cols=readInt()+1; // number cols
	  		int rows=readInt(); // number rows
	  		cx=readInt(); // local color prec
	  		readInt(); // cell color prec
	  		readInt();  // FIXME, Whats that?
	  		int d = cols*rows;
	  		int[] ca = new int[d];
  			for (int i=0; i<d;i++) 
		  			ca[i] = readColor(COLOR_MODE_INDEXED).getRGB();
	  		cgm.currpic.cellArray(x1,y1,x2 ,y2, ca, cols, rows);
			break;
		}
		if (cgmCommand.equals("LINEWIDTH")) {
			ContextOrPicture.LineWidth=readFloat();
			break;
		}
		if (cgmCommand.equals("TEXTINDEX")) {
			break;
		}
		if (cgmCommand.equals("CHAREXPAN")) {
			ContextOrPicture.CharacterExpansion=readFloat();
			break;
		}
		if (cgmCommand.equals("CHARSPACE")) {
			ContextOrPicture.CharacterSpacing=readFloat();
			break;
		}
		if (cgmCommand.equals("TEXTALIGN")) {
			ContextOrPicture.TextAlignHor = readKeyword("1LEFT2CENTRE3RIGHT",0);
			ContextOrPicture.TextAlignVert = readKeyword("0TOP1CAP2HALF3BASE4BOTTOM",0);
// Don't care about baseX and baseY
			break;
		}
		if (cgmCommand.equals("EDGEWIDTH")) {
			ContextOrPicture.EdgeWidth=readFloat();
			break;
		}
		if (cgmCommand.equals("COLRTABLE")) {
		    a = readInt();
	  		while (true) {
		        if (a > ctSize) {
			      ctSize += 256;
 		          Color[] ct = new Color[ctSize+1];
		          System.arraycopy(ColorTable, 0,ct , 0, ctSize-255);
		          ColorTable = ct;
		        }
				Color col=readColor(COLOR_MODE_DIRECT);
				if (col == null) break;
	    		try { ColorTable[a]=col; }
	    		catch (ArrayIndexOutOfBoundsException e) {
	  	  			System.out.println("ColorTable Array out of bounds: "+a);
	 			}
				a++;
	  		}
	  		ColorMode=COLOR_MODE_INDEXED;
//			break;
		}
/*
		if (cgmCommand.equals("FILLINDEX")) {
			break;
		}
		if (cgmCommand.equals("EDGEINDEX")) {
			break;
		}
		if (cgmCommand.equals("LINEINDEX")) {
			break;
		}
		if (cgmCommand.equals("MFVERSION")) {
			break;
		}
		if (cgmCommand.equals("INDEXPREC")) {
			break;
		}
		if (cgmCommand.equals("SCALEMODE")) {
			break;
		}
		if (cgmCommand.equals("FILLREFP1")) {
			break;
		}
		notifyUnknown(cgmCommand);
*/
		break;		
	case 10:
		if (cgmCommand.equals("CHARHEIGHT")) {
			ContextOrPicture.CharacterHeight=Math.abs(readFloat()*ContextOrPicture.ay);
			break;
		}
		if (cgmCommand.equals("MARKERTYPE")) {
			ContextOrPicture.MarkerType=readInt();
			break;
		}
		if (cgmCommand.equals("MARKERSIZE")) {
			ContextOrPicture.MarkerSize=readFloat();
			break;
		}
		if (cgmCommand.equals("MARKERCOLR")) {
			ContextOrPicture.MarkerColor=readColor();
			break;
		}
		if (cgmCommand.equals("HATCHINDEX")) {
			ContextOrPicture.HatchIndex=readInt();
//			break;
		}
/*
		if (cgmCommand.equals("BEGPICBODY")) {
			break;
		}
		if (cgmCommand.equals("MFELEMLIST")) {
			break;
		}
		if (cgmCommand.equals("CHARCODING")) {
			break;
		}
		if (cgmCommand.equals("INCRMARKER")) {
			break;
		}
		if (cgmCommand.equals("POLYGONSET")) {
			break;
		}
		notifyUnknown(cgmCommand);
*/
		break;		
	case 11:
		if (cgmCommand.equals("ARC3PTCLOSE")) {
	  		cgm.currpic.circarc(readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readKeyword("1PIE",0));
			break;
		}
		if (cgmCommand.equals("ARCCTRCLOSE")) {
	  		cgm.currpic.circarc(readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readKeyword("1PIE",0));
//			break;
		}
/*
		if (cgmCommand.equals("MARKERINDEX")) {
			break;
		}
		if (cgmCommand.equals("CHARSETLIST")) {
			break;
		}
		if (cgmCommand.equals("INTEGERPREC")) {
			break;
		}
		if (cgmCommand.equals("VDCREALPREC")) {
			break;
		}
		if (cgmCommand.equals("INCRPOLYGON")) {
			break;
		}
		notifyUnknown(cgmCommand);
*/
		break;		
	case 12:
		if (cgmCommand.equals("MAXCOLRINDEX")) {
	 	 	a = readInt();
	  		if (a > 256) ColorTable=new Color[a+1];
			break;
		}
		if (cgmCommand.equals("COLRVALUEEXT")) {
			colr1 = (int) readFloat();
			colg1 = (int) readFloat();
			colb1 = (int) readFloat();
			colr2 = 255/(readFloat()-colr1);
			colg2 = 255/(readFloat()-colg1);
			colb2 = 255/(readFloat()-colb1);
//			break;
		}
/*
		if (cgmCommand.equals("TRANSPARENCY")) {
			break;
		}
		if (cgmCommand.equals("CHARSETINDEX")) {
			break;
		}
		notifyUnknown(cgmCommand);
*/
		break;		
	case 13:
		if (cgmCommand.equals("LINEWIDTHMODE")) {
			ContextOrPicture.LineWidthMode = readKeyword("1ABS",0); 
			break;
		}
		if (cgmCommand.equals("EDGEWIDTHMODE")) {
			ContextOrPicture.EdgeWidthMode = readKeyword("1ABS",0);
			break;
		}
		if (cgmCommand.equals("ELLIPARCCLOSE")) {
	  		cgm.currpic.elliparc(readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readFloat(),readKeyword("1PIE",0));
			break;
		}
		if (cgmCommand.equals("TEXTFONTINDEX")) {
			ContextOrPicture.FontIndex=Math.max(1,readInt());
//			break;
		}
/*
		if (cgmCommand.equals("INCRDISJTLINE")) {
			break;
		}
		if (cgmCommand.equals("COLRINDEXPREC")) {
			break;
		}
		if (cgmCommand.equals("BEGMFDEFAULTS")) {
			break;
		}
		if (cgmCommand.equals("ENDMFDEFAULTS")) {
			break;
		}
		notifyUnknown(cgmCommand);
*/
		break;		
	case 14:
		if (cgmCommand.equals("MARKERSIZEMODE")) {
			ContextOrPicture.MarkerSizeMode = readKeyword("1ABS",0);
//			break;
		}
/*
		if (cgmCommand.equals("VDCINTEGERPREC")) {
			break;
		}
		if (cgmCommand.equals("INCRPOLYGONSET")) {
			break;
		}
		notifyUnknown(cgmCommand);
		break;
	case 15:
		if (cgmCommand.equals("ALTCHARSETINDEX")) {
			break;
		}
		notifyUnknown(cgmCommand);
		break;
	default:
		notifyUnknown(cgmCommand);
		break;
*/
  		}
	  	skip();
	    }
		catch (EOFException e) {
	  		if (cgm.currpic!=null)
	  		cgm.endMF();
	  		break;
		}
	    catch (Exception e) {
		  	System.out.println(e);
	    }
	  }
	}
	catch (EOFException e) {
	  if (cgm.currpic!=null)
	  cgm.endMF();
	}
}
private final double readFloat() throws IOException,Exception {

	if (nextToken() == StreamTokenizer.TT_NUMBER) {
		return (tokenizer.nval);
	} 
	throw new Exception("cgmVA: Number expected, line "+nin.lineno);
}
protected final int readInt() throws IOException, Exception {

	if (nextToken() == StreamTokenizer.TT_NUMBER) {
		return (int) (tokenizer.nval);
	} 
	throw new Exception("cgmVA: Integer expected, line "+nin.lineno);
}
/**
 * 
 * @return int
 */
private final int readKeyword(String keylist,int def) {
	try {
	switch (nextToken()) {
	case StreamTokenizer.TT_WORD:
	  return Character.digit(keylist.charAt(keylist.indexOf(tokenizer.sval.toUpperCase())-1),10);
	case StreamTokenizer.TT_NUMBER:
	  return (int) tokenizer.nval;
	default:
	  return def;
	}
	}
	catch (Exception f) {
 	  return def;
	}

}
private final double[] readPoints(boolean flags) throws IOException {
	Vector pieces = new Vector(5,5);
	int cnt = 100;
	int tot = 0;
	int p = 0;
	double[] points = null;
	while (true) {
		if (cnt == 100) {
			points = new double[100];
			pieces.addElement(points);
			cnt = 0;
		}
		int token = nextToken();
		if ((token == ';') || (token == '/')) break;
		if (token == StreamTokenizer.TT_NUMBER) {
			if ((flags) && (p++ == 3)) {
				p = 0;
				continue;
			}
			points[cnt] = tokenizer.nval;
			cnt++;
			tot++;
		}
	}
	double[] allpoints = new double[tot];
	cnt=0;
	while (tot > 0) {
		points = (double[]) pieces.elementAt(cnt);
		System.arraycopy(points, 0, allpoints, cnt*100, Math.min(100,tot));
		tot -= 100;
		cnt++;
	}
	return  allpoints;
}
private final String readString() throws IOException,Exception{

	int c = nextToken();
	if ((c == '\'') || (c== '"')) 
		return tokenizer.sval;
	throw new Exception ("cgmVA: String expected, line "+nin.lineno);
}
private final void skip()  throws IOException {
	while ((tokenizer.ttype != ';') && (tokenizer.ttype != '/'))
		nextToken();
}
}
