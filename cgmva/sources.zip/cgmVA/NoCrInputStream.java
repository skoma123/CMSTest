/**
 * Filtered input stream (removes CR/LF)
 *
 * @author      (C) 1999 Berthold Daum (bdaum@online.de)
 * @version     1.0a, 3/1/99
 * @since       CGMView 1.0
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.io.IOException;

class NoCrInputStream extends java.io.FilterInputStream {
	int lineno = 1;
	private boolean nl = false;
/**
 * NoCrInputStream constructor comment.
 * @param in java.io.InputStream
 */
protected NoCrInputStream(java.io.InputStream in) {
	super(in);
}
	public final int read() throws IOException {
	int c = in.read();
	if (c == '\r') {
		lineno++;
		nl = true;
		return ' ';
	}
	if (c == '\n' ) {
		if (nl) {
			nl = false;
			return in.read();
		}
		lineno++;
		return ' ';
	}
	nl = false;
	return c;
	}
}
