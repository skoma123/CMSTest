import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

/**
 * CGM context 
 *
 * @author 		� 1996 Alexander Larsson (alla@lysator.liu.se)
 * @author      � 1998 Berthold Daum (bdaum@online.de)
 * @version     1.5, 01/10/2001
 * @since       CGMView 0.1
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Changes:
 * 16-11-98: Added support for underlined fonts. bd
 * 14-1-2001: Added find(String,int). bd
 * 01-10-2001: Inverse Color.bd
 */

class CgmContext extends Cgm {
  CgmPicture currpic=null;
  Vector pictures=new Vector(5,2);
  boolean FinishedLoading=false;
  String filename;
  int SearchResult;
  Vector  FontList = new Vector(5,2);
  boolean FinishedReading=false;
  InputStream is=null;
  CgmReader reader=null;
  CgmContext(CgmViewApplet applet,String fn) {
	this.applet = applet;
	this.BackColor= null;
	this.filename = fn;
	if (applet.inverseColor)
	{
	this.FillColor           = Color.black;
	this.EdgeColor           = Color.cyan;
	this.LineColor           = Color.magenta;
	this.MarkerColor		 = Color.white;
	this.TextColor           = Color.yellow;
	} else {
	this.FillColor           = Color.white;
	this.EdgeColor           = Color.red;
	this.LineColor           = Color.green;
	this.MarkerColor		 = Color.black;
	this.TextColor           = Color.blue;
	}
  }                  
  final void addFont(String str) {
	int fontStyle=Font.PLAIN;
	int i = str.indexOf(' ');
	if (i >= 0) {
		if (str.indexOf("Bold") >= 0)
			fontStyle = Font.BOLD;
		if (str.indexOf("Italic") >= 0)
			fontStyle = fontStyle | Font.ITALIC;
		if (str.indexOf("Underline") >= 0)
			fontStyle = fontStyle | 128;
		FontList.addElement(new Font(str.substring(0, i),fontStyle,12));
	}	else {
  		FontList.addElement(new Font(str,fontStyle,12));
  }	
  }  
  final void beginMF(String name) {
	FinishedLoading=false;
	this.name=name;
	  }
  final void beginPic(String name) {
	currpic = new CgmPicture(this,name);
	pictures.addElement(currpic);
  }  
  final void endMF() {
	FinishedLoading=true;
  }  
/**
 * This method was created in VisualAge.
 */
final CgmContext find(double px, double py ) {
	SearchResult = -1;
	for (int i=pictures.size()-1;i >= 0; i--) {
		CgmPicture pic = (CgmPicture) pictures.elementAt(i);
		if (SearchResult < 0) 
 			SearchResult = pic.find(px,py);
 		else
			SearchResult += pic.PrimList.size();
	}
	return (SearchResult >= 0) ? this : null;
}
/**
 * This method was created in VisualAge.
 */
final CgmContext find(String t,int m) {
	SearchResult = m;
	for (int i=pictures.size()-1;i >= 0; i--) {
		CgmPicture pic = (CgmPicture) pictures.elementAt(i);
		if (SearchResult < 0) 
 			SearchResult = pic.find(t,SearchResult);
 		else
			SearchResult += pic.PrimList.size();
	}
	return (SearchResult >= 0) ? this : null;
}
/**
 * Find component at index i
 * Creation date: (01.01.01 12:24:11)
 * @return CgmPicture
 * @param i int
 */
protected final CgmPrimitive findComponent(int c) {
	for (int i=0; i < pictures.size(); i++) {
		CgmPicture pic = (CgmPicture) pictures.elementAt(i);
		int s = pic.PrimList.size();
		if (c < s) return (CgmPrimitive) pic.PrimList.elementAt(c);
		c -= s;
	}
	return null;
}
	final void finishReading ( ) {
	if (!FinishedReading) {
	  reader.waitFor();
	  if (is != null) {
	  	try { is.close(); } catch (IOException e) {  }
	  	is=null;
	  }
	  reader=null;
	  FinishedReading=true;
	}
	return;
}
final void getReader(DataInputStream dis) throws IOException {
	byte c1 = 0;
	if (dis.markSupported()) {
	  	dis.mark(1);
	  	c1 = dis.readByte();
	  	dis.reset();
	}
	if (c1 == 'B')
		this.reader=new CgmAsciiReader(dis,this);
	else
 		this.reader=new CgmBinReader(dis,this);
}
final void render(Graphics g,double factorX, double factorY, boolean vis ) {
 	for (int i=0;i<pictures.size();i++) 
	 	((CgmPicture) pictures.elementAt(i)).render(g,factorX,factorY,vis);
}
final int replaceText (int n, String txt ) {
	for (int i=0;i<pictures.size();i++) {
		n = ((CgmPicture) pictures.elementAt(i)).replaceText(n,txt);
		if (n<0) break;
	}
	return n;
}
}
