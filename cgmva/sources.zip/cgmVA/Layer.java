/**
 * Layer manager
 *
 * @author      � 1998 Berthold Daum (bdaum@online.de)
 * @version     1.4 14/1/2001
 * @since       CGMView 0.3
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * changes: 14-1-2001: added find(String,int). bd
 */
import java.util.*;
import java.awt.*;

class Layer implements Visibility{

	Vector Images = new Vector(1,10);
	int visibility = SHOW;
	double x = 0;
	double y = 0;
	double factorX = 1;
	double factorY = 1;
	double clipx=0;
	double clipy=0;
	double clipw=1;
	double cliph=1;
	int SearchResult;


Layer () {
}
final LayerElement find (double x,double y,double factorX,double factorY,double px,double py) {
	if ((visibility == HIDDEN) || (this.factorX < 0.001) || (this.factorY < 0.001)) return null;
	double x1 = x+this.x*factorX;
	double y1 = y+this.y*factorY;
	double fx1 = factorX*this.factorX;
	double fy1 = factorY*this.factorY;
	for (int i=Images.size()-1;i>=0;i--) {
		LayerElement e = (LayerElement) Images.elementAt(i);
		if (e.find(x1,y1,fx1,fy1,px,py)) return e;
	}	
	return null;
}
final LayerElement find (String t,int m) {
	SearchResult = m;
	LayerElement r = null;
	if ((visibility == HIDDEN)) return null;
	for (int i=Images.size()-1;i>=0;i--) {
		LayerElement e = (LayerElement) Images.elementAt(i);
		SearchResult = e.find(t,SearchResult);
		if (SearchResult >= 0) r = e;
	}	
	return r;
}
final void render (Graphics g, double x,double y,double factorX,double factorY,double factor) {
	if ((visibility <= STEALTH) || (this.factorX < 0.001) || (this.factorY < 0.001)) return;
	try { g.clipRect((int)(clipx*factor),(int)(clipy*factor),(int)(clipw*factor),(int)(cliph*factor)); }
	catch (Exception e) {}
	double x1 = x+this.x*factorX;
	double y1 = y+this.y*factorY;
	double fx1 = factorX*this.factorX;
	double fy1 = factorY*this.factorY;
	for (int i=0;i<Images.size();i++) {
		LayerElement e = (LayerElement) Images.elementAt(i);
		e.render(g, x1,y1,fx1,fy1,(visibility == SHOW));
	}	
}
}
