/**
 * Layer element
 *
 * @author      � 1998 Berthold Daum (bdaum@online.de)
 * @version     1.4, 14/1/2001
 * @since       CGMView 0.3
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * changes 14-1-2001: added find(String,int). bd
 */

import java.awt.Graphics;

class LayerElement implements Visibility{

	CgmContext cgm;
	int visibility = SHOW;
	double x=0;
	double y=0;
	double factorX=1;
	double factorY=1;
	String id = "";
	String clonename = "";
	int SearchResult;

LayerElement ( CgmContext cgm, String id) {
	this.cgm = cgm;
	this.id = id;
}
public final boolean equals ( Object e) {
	return ((this.cgm == ((LayerElement) e).cgm) && (this.id.equals(((LayerElement) e).id)));
}
final boolean find (double x,double y,double factorX,double factorY,double px, double py) {
	if ((visibility == HIDDEN) || (this.factorX < 0.001) || (this.factorY < 0.001)) return false;
	cgm.finishReading();
 	CgmContext s = cgm.find((px-(x+this.x*factorX))/(this.factorX*factorX),(py-(y+this.y*factorY))/(this.factorY*factorY));
	if (s != null) {
		clonename = cgm.filename+id;
		SearchResult = cgm.SearchResult;
		return true;
	}
	return false;
}
final int find (String t,int m) {
	if ((visibility == HIDDEN)) return m;
	cgm.finishReading();
 	CgmContext s = cgm.find(t,m);
	if (s != null) {
		clonename = cgm.filename+id;
		SearchResult = cgm.SearchResult;
		return SearchResult;
	}
	return m;
 	} 
final void render (Graphics g, double x,double y,double factorX,double factorY,boolean lvis) {
	if ((visibility <= STEALTH) || (this.factorX < 0.001) || (this.factorY < 0.001)) return;
	cgm.finishReading();
	int xo = (int) (x+this.x*factorX);
	int yo = (int) (y+this.y*factorY);
	g.translate(xo,yo);
 	cgm.render(g,this.factorX*factorX,this.factorY*factorY,((visibility == SHOW) & lvis));
 	g.translate(-xo,-yo);
}
final void replaceText (int n,String txt ) {
	cgm.finishReading();
	cgm.replaceText(n,txt);
}
}
