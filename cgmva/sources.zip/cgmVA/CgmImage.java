/**
 * Bitmap image object
 *
 * @author      (C) 1998 Berthold Daum (bdaum@online.de)
 * @version     0.5a, 11/12/98
 * @since       CGMView 0.4
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;
import java.awt.image.*;

class CgmImage extends CgmPrimitive implements ImageObserver {
    Image img = null;

    boolean rendered = true;

    boolean standalone = true;

    CgmViewApplet applet;

    double norm = 1;

    CgmImage(Image img, CgmViewApplet target) {
        this.img = img;
        Width = 1;
        Height = 1;
        applet = target;
    }

    CgmImage(Image img, CgmViewApplet target, double x1, double y1, double x2,
            double y2) {
        x = x1;
        y = y1;
        Width = (x2 - x1);
        Height = Math.abs(y1 - y2);
        this.img = img;
        applet = target;
        standalone = false;
    }

    final void draw(Graphics g, double w, double h, boolean fill) {
        int imgW = img.getWidth(this);
        int imgH = img.getHeight(this);
        norm = 1.0 / Math.max(imgW, imgH);
        if (standalone) {
            Width = imgW * norm;
            Height = imgH * norm;
        }
        int appW = applet.Width;
        int appH = applet.Height;

        int canvasX = applet.canvasX;
        int canvasY = applet.canvasY;

        double canvasW = applet.canvasWidth;
        double canvasH = applet.canvasHeight;

        double imgMagW = Width * w;
        double imgMagH = Height * h;

        double canvTargX = Math.max(0, (canvasW - imgMagW) / 2);
        double canvTargY = Math.max(0, (canvasH - imgMagH) / 2);

        x = canvTargX * norm;
        y = canvTargY * norm;

        if (fill) {

            // double canvSrcX = Math.max(0,(imgMagW-canvasW))/(2*w*norm);
            // double canvSrcY = Math.max(0,(imgMagH-canvasH))/(2*h*norm);

            double appTargX = Math.max(canvTargX, canvasX);
            double appTargY = Math.max(canvTargY, canvasY);

            double appTargW = Math.min(imgMagW, appW);
            double appTargH = Math.min(imgMagH, appH);

            double extendX = Math.min(applet.origX, Math.max(0, appTargX
                    - canvTargX));
            double extendY = Math.min(applet.origY, Math.max(0, appTargY
                    - canvTargY));

            double appSrcX = (appTargX - canvTargX - extendX) / (w * norm);
            double appSrcY = (appTargY - canvTargY - extendY) / (h * norm);

            double appSrcW = Math.min(appTargW / (w * norm), imgW - appSrcX);
            double appSrcH = Math.min(appTargH / (h * norm), imgH - appSrcY);

            double TargX = appTargX - extendX;
            double TargY = appTargY - extendY;
            g.drawImage(img, (int) TargX, (int) TargY,
                    (int) (TargX + appTargW), (int) (TargY + appTargH),
                    (int) appSrcX, (int) appSrcY, (int) (appSrcX + appSrcW),
                    (int) (appSrcY + appSrcH), this);
            while (!rendered) {
                try {
                    Thread.sleep(20);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }

    final boolean find(double x, double y) {
        if ((visibility != HIDDEN) && (x >= this.x) && (y >= this.y)
                && (x <= this.x + Width) && (y <= this.y + Height)) {
            return testPixel(img, (int) ((x - this.x) / norm),
                    (int) ((y - this.y) / norm));
        }
        return false;
    }

    final public boolean imageUpdate(Image img, int infoflags, int x, int y,
            int width, int height) {
        rendered = ((infoflags & ALLBITS) != 0);
        return (infoflags & (ALLBITS | ERROR)) == 0;
    }

    final void move(double mx, double my) {
        return;
    }

    final boolean testPixel(Image img, int x, int y) {
        int[] pixels = new int[1];
        PixelGrabber pg = new PixelGrabber(img, x, y, 1, 1, pixels, 0, 1);
        try {
            pg.grabPixels();
        } catch (InterruptedException e) {
            return false;
        }
        if ((pg.getStatus() & ImageObserver.ABORT) != 0)
            return false;
        return (((pixels[0] >> 24) & 0xff) > 127);
    }
}
