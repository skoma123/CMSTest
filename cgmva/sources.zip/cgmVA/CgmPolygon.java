/**
 * Polygon/Polyline object
 *
 * @author      (C) 1998 Berthold Daum (bdaum@online.de)
 * @version     1.4, 7/5/99
 * @since       CGMView 0.2
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * 14-01-01 bd fixed problem with small polylines and linewidth > 1
 */
import java.awt.*;
class CgmPolygon extends CgmPrimitivePoly {
	int p;
	static final double HATCHWIDTH = 0.002;
	static final int LINE_HATCH_SIZE=8;
	static final int LINE_POINT_SIZE=4;
	static final int LINE_GAP_SIZE=4;
 CgmPolygon (int pnts, boolean c ) {
	int p1 = pnts+1;
	xpoints=new double[pnts];
	ypoints=new double[pnts];
	xpoints1=new int[p1];
	ypoints1=new int[p1];
	points=pnts;
    closed = c;
	p = (c) ? p1 : pnts;
}
final void draw(java.awt.Graphics g,double w, double h, boolean fill)  {
int i;
	if ((previousW != w) || (previousH != h)) {
		for (i=0;i<points;i++) {
	  		xpoints1[i]=(int) (xpoints[i]*w+0.6);
	  		ypoints1[i]=(int) (ypoints[i]*h+0.6);
		}
		lw=(int) (LineWidth*w+0.5);
	  	xpoints1[points] = xpoints1[0];
	  	ypoints1[points] = ypoints1[0];
		previousW = w;
		previousH = h;
	}
	if ((fill) && (IntStyle >= 1) ) {
		g.setColor(FillColor);
		if (IntStyle == 1)
			g.fillPolygon(xpoints1,ypoints1,p);
		else {
/* FIXME fill styles
2 - horizontal lines
3 - vertical lines 
4 - lines of positive slope (not supported)
5 - lines of negative slope (not supported)
6 - horizontal and vertical lines 
7 - lines of positive and negative slope (not supported)
	The default hatch fill is horizontal lines.
	
*/
			double hw = ((IntStyle < 4) || (IntStyle == 6)) ? HATCHWIDTH : HATCHWIDTH/2;
			Shape clp = g.getClip();
			if ((IntStyle == 2) || (IntStyle == 4) || (IntStyle >= 6)) {
				int hh = (int)(hw*h);
				if (hh == 0) hh = 1;
				int inc = hh*5;
				int yfro = ((int)(this.y*h)/inc)*inc;
				int yto = (int)((this.y+this.Height)*h);
				int wl = (int) w;
				for (int yl = yfro;yl <= yto; yl+=inc) {
					g.clipRect(0,yl,wl,hh);
					g.fillPolygon(xpoints1,ypoints1,p);
					g.setClip(clp);
				}
			}
			if ((IntStyle == 3) || (IntStyle >= 5)) {
				int hh = (int)(hw*w);
				if (hh == 0) hh = 1;
				int inc = hh*5;
				int xfro = ((int)(this.x*w)/inc)*inc;
				int xto = (int)((this.x+this.Width)*h);
				int hl = (int) h;
				for (int xl = xfro;xl <= xto; xl+=inc) {
					g.clipRect(xl,0,hh,hl);
					g.fillPolygon(xpoints1,ypoints1,p);
					g.setClip(clp);
				}
			}
		}
	}
	if (LineColor != null) {
 	    g.setColor(LineColor);
		if ((LineType > 1) && (p < w)) { // use normal line if average segment width < 1
			drawHatchedLine(g,xpoints1,ypoints1,p,lw,LineType);
			return;
		}
		if (lw<=1) {  //use standard polyline for linewidth <= 1
	  		g.drawPolyline(xpoints1,ypoints1,p);
	  		return;
		}
		if (p == 2) { //just a simple line
			drawLine(g,xpoints1[0],ypoints1[0],xpoints1[1],ypoints1[1],lw);
			return;
		}
  		drawPolyline (g, xpoints1, ypoints1, p,  lw );  // the works
	}
}
static final void drawHatchedLine(Graphics g,int[] xpoints,int [] ypoints,
				  int p,int lw,int type) {
int x1 = xpoints[1];
int y1 = ypoints[1];
int x2,y2,k,n,ix2,iy2,xh1,yh1,xh2,yh2,i,xx1,yy1,xx2,yy2,xx3,yy3,xx4,yy4;
int xd=0,yd=0,xd2=0,yd2=0;
double hh,dx,dy,h1,h2,ix,iy,dd1,dd2,dd3,a;
	switch(type) {
	case 3:
		h1 = LINE_POINT_SIZE;
		h2 = LINE_POINT_SIZE;
		break;
	case 4:
		h1 = LINE_HATCH_SIZE;
		h2 = LINE_POINT_SIZE;
		break;
	default:
		h1 = LINE_HATCH_SIZE;
		h2 = LINE_HATCH_SIZE;
	}
	hh = h1+h2+(LINE_GAP_SIZE<<1);
	dd1 = h1/hh;
	dd2 = h2/hh;
	dd3 = (h1+LINE_GAP_SIZE)/hh;

   Rectangle clip = g.getClipRect();
   int cx = clip.x;
   int cy = clip.y;
   int cx2 = clip.width+cx;
   int cy2 = clip.height+cy;
	
for (k=1;k<p;k++) {
	x2 = xpoints[k];
	y2 = ypoints[k];

	if ((x2 >= cx) && (x1 <= cx2) && (y2 >= cy) && (y1 <= cy2)) {
	dx = x2-x1;
	dy = y2-y1;
	n = (int) ((dx > dy) ? dx/hh : dy/hh);
	if (n==0) n=1;
	ix = dx/n;
	iy = dy/n;
	ix2 = (int) (ix*dd3);
	iy2 = (int) (iy*dd3);
	xh1 = (int) (ix*dd1);
	yh1 = (int) (iy*dd1);
	xh2 = (int) (ix*dd2);
	yh2 = (int) (iy*dd2);
	if ((xh1 == 0) && (yh1 == 0)) {
		if (lw > 1)
			drawLine(g,x1,y1,x2,y2,lw);
		else
			g.drawLine(x1,y1,x2,y2);
	} else {
	if (lw > 1) {
  		if (dx == 0) {
			xd = lw;
			yd = 0;
	 	} else {
  			if (dy == 0) {
				yd = lw;
				xd = 0;
	 		} else {
				xd = -(int)(lw*Math.sin(a=Math.atan(dy/dx))+.5);
				yd = (int)(lw*Math.cos(a)+.5);
			}	
	 	}
   		xd2 = xd>>1;
   		yd2 = yd>>1;
	}	
	for (i=0;i<n;i++) {
		xx1 = x1+ (int)(i*ix);
		yy1 = y1+ (int)(i*iy);
		xx2 = xx1+ xh1;
		yy2 = yy1+ yh1;
		xx3 = xx1+ ix2;
		yy3 = yy1+ iy2;
		xx4 = xx3+ xh2;
		yy4 = yy3+ yh2;
		if (lw <= 1) {
			g.drawLine(xx1,yy1,xx2,yy2);
			g.drawLine(xx3,yy3,xx4,yy4);
		} else {
	  		int[] xCorners = { xx1-xd2, xx2-xd2,
			 xx2+xd-xd2, xx1+xd-xd2 };
	  		int[] yCorners = { yy1-yd2, yy2-yd2,
			 yy2+yd-yd2, yy1+yd-yd2 };
			g.fillPolygon(xCorners,yCorners,4);
	  		int[] xCorners2 = { xx3-xd2, xx4-xd2,
			 xx4+xd-xd2, xx3+xd-xd2 };
	  		int[] yCorners2 = { yy3-yd2, yy4-yd2,
			 yy4+yd-yd2, yy3+yd-yd2 };
			g.fillPolygon(xCorners2,yCorners2,4);
		}
	}
	}
	}
	x1 = x2;
	y1 = y2;
}
}
 //----------------------------------------------------
  /** Draws a line from (x1, y1) to (x2, y2) using the
   *  specified pen thickness.
   *
   * @param g The Graphics object.
   * @param x1 x position of start of line.
   * @param y1 y position of start of line.
   * @param x2 x position of end of line.
   * @param y2 y position of end of line.
   * @param lineWidth Thickness of line drawn.
   */
  
  static final void drawLine(Graphics g,
							  int x1, int y1,
							  int x2, int y2,
							  int lw) {

	if (x1 == x2) {
		if (y1 != y2)
			g.fillRect(x1-(lw>>1),(y1 < y2) ? y1 : y2,lw,(y2 < y1) ? y1-y2 : y2-y1);
		return;
	}
	if (y1 == y2) {
		g.fillRect((x1 < x2) ? x1 : x2,y1-(lw>>1),(x2 < x1) ? x1-x2 : x2-x1,lw);
		return;
	}
	double angle = Math.atan(((double)(y2-y1))/((double)(x2-x1)));
	int xOffset = -(int)(lw*Math.sin(angle)+.5);
	int yOffset = (int)(lw*Math.cos(angle)+.5);
	int xOffset2 = xOffset>>1;
	int yOffset2 = yOffset>>1;
	int[] xCorners = { x1-xOffset2, x2-xOffset2,
		 x2+xOffset-xOffset2, x1+xOffset-xOffset2 };
	int[] yCorners = { y1-yOffset2, y2-yOffset2,
		 y2+yOffset-yOffset2, y1+yOffset-yOffset2 };
	g.fillPolygon(xCorners, yCorners, 4);
  }  
static final void drawPolyline (Graphics g, int[] x, int[] y, int points, int lw ) {

int px1=0,px2=0,py1=0,py2=0,px3,px4,py3,py4;
double A1=0,B1=0,C1,P1=0,Q1=0,A2,B2,C2,P2,Q2,W;
double l2=lw*H5;
int p1 = points-1;
int i,i1,i0,xd,yd,xd2,yd2;
int firstNode=0,lastNode=p1,lastDone=0,init = -2;
// wrap around for proper edges if polyline is closed.
	if ((x[0] == x[p1]) && (y[0] == y[p1])) {
		firstNode = -1;
		lastNode = points;
	}
	for (i=firstNode;i < lastNode;i++) {
// compute  indices for wrap around
		i0 = ((i < 0) ? points-2 : ((i == p1) ? 0 : i));
		i1 = i0+1;
		A2 = y[i1]-y[i0];
		B2 = x[i0]-x[i1];
		if (init < firstNode) {
// prepare start corners
			A1 = A2;
			B1 = -B2;
			init = i;
  			if (B1 == 0) {
 				xd = (A1 < 0) ? -lw : lw;
  				yd = 0;
			} else {
				xd = (int)(lw*Math.sin(C1=Math.atan(A1/B1))+H5);
				yd = (int)(lw*Math.cos(C1)+H5);
				if ((A1 >= 0) && (B1 < 0)) xd = -xd;
				if (B1 > 0) yd = -yd;
			}
  			xd2 = xd>>1;
  			yd2 = yd>>1;
 			px1 = x[i0]-xd2;
			py1 = y[i0]-yd2;
			px2 = x[i0]+xd-xd2;
			py2 = y[i0]+yd-yd2;
		}
// compute  straight	
		C2 = x[i1]*y[i0]-y[i1]*x[i0];
		W = Math.sqrt(A2*A2+B2*B2)*l2;
// left and right parallels
		P2 = C2+W;
		Q2 = C2-W;
		if ((A1 != 0) || (B1 != 0)) {  // big enough to draw?
// compute intersecting points
  		  W = A1*B2-A2*B1;
		  if (W != 0) { // cut out non-intersecting lines
			lastDone = i;
// intersecting points left and right
			px3 = (int) ((P2*B1-P1*B2)/W+H5);
			py3 = (int) ((P1*A2-P2*A1)/W+H5);
			px4 = (int) ((Q2*B1-Q1*B2)/W+H5);
			py4 = (int) ((Q1*A2-Q2*A1)/W+H5);
			if ((i > 0) && (i < points)) {
				int[] xCorners = {px1,px3,px4,px2};
				int[] yCorners = {py1,py3,py4,py2};
				g.fillPolygon(xCorners,yCorners,4);
			}
// use current end points as next start points
			if (i > init) {
				px1 = px3;
				py1 = py3;
				px2 = px4;
				py2 = py4;
			}	
		  }
		}
// reuse current straight for next intersection
		A1 = A2;
		B1 = B2;
		P1 = P2;
		Q1 = Q2;
	}
// left and right corners at end
	A1 = y[lastDone]-y[p1];
	B1 = x[lastDone]-x[p1];
	if ((A1 != 0) || (B1 != 0)) {
  		if (B1 == 0) {
	  		xd = (A1 >= 0) ? -lw : lw;
  			yd = 0;
		} else {	
			xd = (int)(lw*Math.sin(C1=Math.atan(A1/B1))+H5);
			yd = (int)(lw*Math.cos(C1)+H5);
			if ((A1 < 0) && (B1 > 0)) xd = -xd;
			if (B1 < 0) yd = -yd;
		}
  	 	xd2 = xd>>1;
   		yd2 = yd>>1;
		px3 = x[p1]-xd2;
		py3 = y[p1]-yd2;
		px4 = x[p1]+xd-xd2;
		py4 = y[p1]+yd-yd2;
		int[] xCorners = {px1,px3,px4,px2};
		int[] yCorners = {py1,py3,py4,py2};
		g.fillPolygon(xCorners,yCorners,4);
	}
}
final boolean find (double x, double y) {
	if ((visibility != HIDDEN) && (IntStyle >= 1) && (closed) && (x >= this.x) && (y >= this.y) && (x <= this.x+Width) && ( y <= this.y+Height)) {
	 	double x1 = xpoints[0];
	 	double y1 = ypoints[0];
	 	double x2,y2,yd,s;
	 	int c=0;
		for (int i1=1;i1<=points;i1++) {
	 		if (i1 < points) {
	 			x2 = xpoints[i1];
	 			y2 = ypoints[i1];
	 		} else {
	 			x2 = xpoints[0];
	 			y2 = ypoints[0];
	 		}
	 		yd = y2-y1;
	 		if (yd != 0.0) {
	 			s = (y-y1)/yd;
				if (((s >= 0.0) && (s <= 1.0 )) && ((x2-x1)*s >= (x-x1)))  c++;
			}
	 		x1 = x2;
	 		y1 = y2;
	 	}
		return ((c & 1) != 0);
	}
	return false;
}
final void setClosed() {
	if (!closed) p++;
	closed = true;
}
}
