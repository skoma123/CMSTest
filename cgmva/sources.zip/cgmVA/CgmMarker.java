/**
 * Polygon/Polyline object
 *
 * @author      (C) 1998 Berthold Daum (bdaum@online.de)
 * @version     1.0a, 27/12/98
 * @since       CGMView 0.4
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

class CgmMarker extends CgmPrimitivePoly {

 CgmMarker(int pnts ) {
	xpoints=new double[pnts];
	ypoints=new double[pnts];
	points=pnts;
}
final void draw(java.awt.Graphics g,double w, double h, boolean fill)  {
	if (LineColor != null) {
	   g.setColor(LineColor);
	   int lw=(int) Math.max(2,LineWidth*w+H5);
	   int lw2 = lw>>1;
	   int lw3 = lw/3;
	   int x,y;
	   for (int i=0;i<points;i++) {
		   x = ((int)(xpoints[i]*w+H6));
		   y = ((int) (ypoints[i]*h+H6));
		   switch (LineType) {
			   case 1:
			   		g.fillOval(x-lw2,y-lw2,lw,lw);
			   		break;
			   case 2:
			   		g.drawLine(x-lw2,y,x+lw2,y);
			   		g.drawLine(x,y-lw2,x,y+lw2);
				   	break;
			   case 4:
			   		g.drawOval(x-lw2,y-lw2,lw,lw);
			   		break;
			   case 5:
			   		g.drawLine(x-lw2,y-lw2,x+lw2,y+lw2);
			   		g.drawLine(x+lw2,y-lw2,x-lw2,y+lw2);
				   	break;
			   default:
			   		g.drawLine(x-lw3,y-lw2,x+lw3,y+lw2);
			   		g.drawLine(x+lw3,y-lw2,x-lw3,y+lw2);
				   	g.drawLine(x-lw2,y,x+lw2,y);
		   }
	   }
	}
}
}
