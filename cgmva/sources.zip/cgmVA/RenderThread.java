/**
 * Render thread
 *
 * @author 		(C) 1996 Alexander Larsson (alla@lysator.liu.se)
 * @author      (C) 1998 Berthold Daum (bdaum@online.de)
 * @version     0.4c, 11/11/98
 * @since       CGMView 0.1
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
import java.awt.*;


class RenderThread extends Thread {
	CgmViewApplet applet;
	double atX;
	double atY;
	double factorX;
	double factorY;
	double factor;
	Image img;
	Layer[] Layers;
	Rectangle clip;

public RenderThread() {
	super();
}
RenderThread ( CgmViewApplet a, double x, double y, double fx, double fy, Image im, Layer[] l, Rectangle c, double f) {
	super("Render-Thread");
	applet = a;
	atX = x;
	atY = y;
	factorX = fx;
	factorY = fy;
	factor = f;
	img=im;
	Layers = l;
	clip = c;
}
public RenderThread(Runnable target) {
	super(target);
}
public RenderThread(Runnable target, String name) {
	super(target, name);
}
public RenderThread(String name) {
	super(name);
}
public RenderThread(ThreadGroup group, Runnable target) {
	super(group, target);
}
public RenderThread(ThreadGroup group, Runnable target, String name) {
	super(group, target, name);
}
public RenderThread(ThreadGroup group, String name) {
	super(group, name);
}
 public void run ( ) {
	Graphics g = img.getGraphics();
	Layer l;
	for (int i=0;i<17;i++) {
		if ((l = Layers[i]) != null) {
			try { g.setClip(clip); } // catch pre 1.1 JDKs
			catch (Throwable e) {
				System.out.println("java.awt JDK 1.1.0 or later required");
				}
			l.render(g,atX,atY,factorX,factorY,factor);
		}	
	}
	applet.showStatus(" ");
	applet.repaint();
  }    
}
