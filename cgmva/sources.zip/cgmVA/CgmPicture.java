/**
 * CGM picture 
 *
 * @author 		� 1996 Alexander Larsson (alla@lysator.liu.se)
 * @author      � 1998 Berthold Daum (bdaum@online.de)
 * @version     1.5, 1/10/2001
 * @since       CGMView 0.1
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Maintenance:
 * 15-11-98: added a trim() in the text method to remove dirt from strings. bd
 * 14-1-2001: added find(String,int). bd
 * 01-10-2001: fixed problem with background color. bd
 * 18-02-2002: discard empty text strings. bd
 * 27-10-2006: fixed problem with arcs with inverted x- and y- axis
 */
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.MemoryImageSource;


public class CgmPicture extends Cgm {
  CgmPrimList PrimList=new CgmPrimList(1000,500);
  CgmContext cgm;
  Font DefaultFont = new Font("Courier",Font.PLAIN,12);
  CgmText PreviousText = null;
  static final int E_SEGM = 45;
  static final int B_SEGM1 = 8;
  static final int B_SEGM2 = 4;
 
  CgmPicture(CgmContext mf,String n) {
  	cgm = mf;
  	name = n;
  	applet = mf.applet;
  	Width = mf.Width;
	Height = mf.Height;
	ax=mf.ax;bx=mf.bx;ay=mf.ay;by=mf.by;
	EdgeWidthMode=mf.EdgeWidthMode;
	LineWidthMode=mf.LineWidthMode;
	MarkerSizeMode=mf.MarkerSizeMode;
	EdgesVisible=mf.EdgesVisible;
	EdgeType=mf.EdgeType;
	LineType=mf.LineType;
	MarkerType=mf.MarkerType;
	EdgeWidth=mf.EdgeWidth;
	LineWidth=mf.LineWidth;
	MarkerSize=mf.MarkerSize;
	InteriorStyle=mf.InteriorStyle;
	HatchIndex=mf.HatchIndex;
	FillColor=mf.FillColor;
	EdgeColor=mf.EdgeColor;
	LineColor=mf.LineColor;
	MarkerColor=mf.MarkerColor;
	BackColor=mf.BackColor;
	TextColor=mf.TextColor;
	CharacterHeight=mf.CharacterHeight;
	CharacterExpansion=mf.CharacterExpansion;
	CharacterSpacing = mf.CharacterSpacing;
	FontIndex=mf.FontIndex;
	CharOri=mf.CharOri;
	CharSlant=mf.CharSlant;
	TextAlignVert = mf.TextAlignVert;
	TextAlignHor = mf.TextAlignHor;
  }            
private final void anyPoly(CgmPrimitivePoly target, double[] points) {
	int l = points.length/2;
	double minx= 1;
	double miny= 1;
	double maxx= 0;
	double maxy= 0;
	double px,py;
	int j = 0;
	for (int i=0;i<l;i++) {
  		target.xpoints[i] = px = ax*points[j++]+bx;
  		target.ypoints[i] = py = ay*points[j++]+by;
  		if (minx > px)  minx = px;
  		if (miny > py)  miny = py;
  		if (maxx < px)  maxx = px;
  		if (maxy < py)  maxy = py;
	}
	target.x = minx;
	target.y = miny;
	target.Width = maxx-minx;
	target.Height = maxy-miny;
	PrimList.addElement(target);                                 
}
/**
 * This method was created in VisualAge.
 */
final void bezier(int t, double[] points) {
	// t=1 discontinuous, t=2 continuous
	int l = points.length;
	if (l > 220) {
		polygon(points,false); // some cheating
		return;
	}
	int l1 = l-1;
	int l2 = l-2;
	int l3 = l-3;
	int n0 = l/2;
	int bp = (((int) (Math.log(l)*B_SEGM1))/n0+B_SEGM2)*n0;
	int n = n0-1;
	int k2=0,k21,j2,k;
	double ch=1,t0,u,t1,tt;
	for (k=0; k <= n;k++) {
		if (k>0) ch = ch*(n0-k)/k;
		points[k2++] *= ch;
		points[k2++] *= ch;
	}
	double[] poly = new double[bp*2+2];
	double[] b = new double[l];
	for (k=0;k <= bp; k++) {
		t0 = ((double) k)/bp;
		u = 1;
		j2 = 0;
		while (j2<l) {
			b[j2] = points[j2++]*u;
			b[j2] = points[j2++]*u;
			u *= t0;
		}
		poly[k2=k+k] = b[l2];
		poly[k21=k2+1] = b[l1];
		tt = t1 = 1-t0;
		j2 =l3;
		while (j2>=1) {
			poly[k21] += b[j2--]*tt;
			poly[k2] += b[j2--]*tt;
			tt *=t1;
		}
	}
	polygon(poly,false);
}
final void cellArray(double x1,double y1,double x2 ,double y2, int[] c, int iw, int ih) {
	Image img = applet.createImage(new MemoryImageSource(iw, ih, c, 0, iw));
	PrimList.addElement(new CgmImage (img,applet,ax*x1+bx,ay*y1+by,ax*x2+bx,ay*y2+by ));
	}
final void circarc(double cx,double cy,
		    double sx,double sy,
		    double ex,double ey,
		    double r,int closed) {
// Java can only handle arc with integer degree, better use polygon through elliptic arc
	elliparc(cx,cy,cx,cy-r,cx+r,cy,sx,sy,ex,ey,closed);
  }  
final void circarc(double x1,double y1,
		    double x2,double y2,
		    double x3,double y3,
		    int closed) {
	double x11 = x1*x1;
	double y11 = y1*y1;
	double y12 = y1-y2;
	double x12 = x1-x2;
	double x22 = x2*x2;
	double y22 = y2*y2;
	double y23 = y2-y3;
	double x23 = x2-x3;
	double x33 = x3*x3;
	double y33 = y3*y3;
	double cx = ((y1-y3)*(x1*x1-x22+y11-y22) + y12*(x33-x22+y33-y22))/(2*(y23*x12-x23*y12));
	double cy = (y23 == 0) ? (x11-x22+y11-y22-2*cx*x12)/(2*y12) : (x22-x33+y22-y33-2*cx*x23)/(2*y23);
 	circarc(cx,cy,x1-cx,y1-cy,x3-cx,y3-cy,Math.sqrt((x1-cx)*(x1-cx)+(y1-cy)*(y1-cy)),closed);
}
  final void disjtLine(double[] points) {

	int l = points.length/2; 
	if (l > 1) {
		CgmDisjtLine ThisDisjtLine=new CgmDisjtLine(l);
		anyPoly(ThisDisjtLine,points);
		setLineAttributes(ThisDisjtLine);
	}
  }  
  final void elliparc(double cx,double cy,
		     double x1,double y1,
		     double x2,double y2,
		     double sx,double sy,
		     double ex,double ey,
		     int closed) {
		double pi = Math.PI;
		double pi2 = pi+pi;
		double dx1 = x1-cx;
		double dy1 = y1-cy;
		double dx2 = x2-cx;
		double dy2 = y2-cy;
		double g,ds;
		double de=pi/2;
		g =  (Math.abs(dx2) > Math.abs(dx1)) ? Math.atan(dy2/dx2)+de : Math.atan(dy1/dx1);
		if (sx != 0) {
			ds = Math.atan(sy/sx);
			if (sx < 0) ds += pi;
		} else 
			ds = (sy < 0) ? -de : de;
		if (ex != 0) {
			de = Math.atan(ey/ex);
			if (ex < 0) de += pi;
		} else if (ey < 0)
			de = -de;
		if (x1 < x2 && y1 < y2 ) { // revert arc direction
			double h = ds;
			ds = de;
			de = h;
		}
		double iv = de-ds;
		if (iv < 0) iv = pi2+iv;
		double a2 = dx1*dx1+dy1*dy1;
		double b2 = dx2*dx2+dy2*dy2;
		double a2b2 = a2*b2;
		double a2mb2 = a2-b2;
		double dsg = ds-g;
		double points[] = new double[2*E_SEGM+((closed==0) ? 2 : 0)];
		int i;
		for (i=0;i < E_SEGM;i++) {
			double d = iv*i/E_SEGM+dsg;
			double cosd = Math.cos(d);
			double r = Math.sqrt(a2b2/(a2-a2mb2*cosd*cosd));
			points[2*i] = cx+r*Math.cos(d+g);
			points[2*i+1] = cy+r*Math.sin(d+g);
		}
		if (closed == 0) {
			points[2*i] = cx;
			points[2*i+1] = cy;
		}
		polygon(points,(closed >= 0));
  }  
  final void ellipse(double cx,double cy,
	       double x1,double y1,
	       double x2,double y2) {
	if ((EdgeType <= 1) && (InteriorStyle <= 1) && (((cx==x1) && (cy==y2)) || ((cx==x2) && (cy==y1)))) {
		CgmOval ThisOval=new CgmOval (ax*cx+bx,ay*cy+by,(cx==x1) ? ax*(x2-cx) : ax*(x1-cx) ,(cy==y2) ? ay*(y1-cy) : ay*(y2-cy));
  		setFillAndLine(ThisOval);
		PrimList.addElement(ThisOval);
		return;
	}
//	  not oval or hatched edges
	double pi2 = Math.PI*2;
	double pi2s = pi2/E_SEGM;
	double dx1 = x1-cx;
	double dy1 = y1-cy;
	double dx2 = x2-cx;
	double dy2 = y2-cy;
	double g = (Math.abs(dx2) > Math.abs(dx1)) ? Math.atan(dy2/dx2)+pi2/4 : Math.atan(dy1/dx1);
	double a2 = dx1*dx1+dy1*dy1;
	double b2 = dx2*dx2+dy2*dy2;
	double points[] = new double[2*E_SEGM];
	double d,cosd,r;
	for (int i=0;i < E_SEGM;i++) {
		r = Math.sqrt((a2*b2)/(a2-(a2-b2)*(cosd = Math.cos(d = pi2s*i))*cosd));
		points[2*i] = cx+r*Math.cos(d+g);
		points[2*i+1] = cy+r*Math.sin(d+g);
	}
	polygon(points,true);
  }  
 final int find(double px,double py) {
	 return PrimList.find(px,py);
 } 
 final int find(String t,int m) {
  	return PrimList.find(t,m);
 } 
final void image(Image img) {
	PrimList.addElement(new CgmImage (img,applet));
}
final void marker(double[] points) {
	int l = points.length/2; 
	if (l > 0) {
		CgmMarker ThisMarker=new CgmMarker(l);
		anyPoly(ThisMarker,points);
		ThisMarker.LineColor = MarkerColor;
		ThisMarker.LineWidth =  MarkerSize*ax;
		ThisMarker.LineType = MarkerType;
	}	
 } 
  final void polygon(double[] points,boolean closed) {
	int l = points.length/2;
	if (l > 1) {
		CgmPolygon ThisPolygon=new CgmPolygon(l,closed);
		anyPoly(ThisPolygon,points);
		if (closed) {
			setFillAndLine(ThisPolygon);
			return;
		}
	 	setLineAttributes(ThisPolygon);
	}	
 }   
  final void rectangle(double x1,double y1,double x2,double y2) {

	if ((EdgeType <= 1) && (InteriorStyle <= 1)) {
		CgmRectangle ThisRectangle=new CgmRectangle (ax*x1+bx,ay*y1+by,ax*x2+bx,ay*y2+by );
		setFillAndLine(ThisRectangle);
		PrimList.addElement(ThisRectangle);
		return;
	} 
	double[] p = {x1,y1,x2,y1,x2,y2,x1,y2};
	polygon(p,true);
  }  
  final void render(Graphics g,double Width,double Height,boolean vis) {
   Rectangle clip = g.getClipRect();
   double cx = clip.x/Width;
   double cy = clip.y/Height;
   PrimList.render(g,Width,Height,cx,clip.width/Width+cx,cy,clip.height/Height+cy,vis);

 } 
final int replaceText (int n, String txt )  {
   return PrimList.replaceText ( n,txt );
 } 
final void setFillAndLine ( CgmPrimitive Target) {
	switch (InteriorStyle) {
		case 1:
		case 2:
			Target.IntStyle = 1;
			break;
		case 3:
			Target.IntStyle = (HatchIndex+1);
			break;
		default:
			Target.IntStyle = 0;
	}
	Target.FillColor = FillColor;
	if (EdgesVisible) {
		Target.LineColor = EdgeColor;
		Target.LineWidth =  EdgeWidth*ax;
		Target.LineType = EdgeType;
	}
}
final void setLineAttributes(CgmPrimitive Target) {
		Target.LineColor = LineColor;
		Target.LineWidth = LineWidth*ax;
		Target.LineType = LineType;
}
  final void text(boolean append,double ex, double ey, double cx,double cy,boolean finaltxt,String str)   {
	String s = str.trim();
	if (s.length() == 0) return;
	CgmText ThisText=new CgmText(Math.abs(ax*ex),Math.abs(ay*ey),ax*cx+bx,ay*cy+by,CharacterHeight,CharOri,CharSlant,CharacterSpacing,s,TextAlignHor,TextAlignVert,TextPath);
	ThisText.applet = applet;
	ThisText.FillColor = TextColor;
	ThisText.setFont((FontIndex > cgm.FontList.size()) ? DefaultFont : (Font) cgm.FontList.elementAt(FontIndex-1));
	ThisText.CharacterExpansion = CharacterExpansion;
	ThisText.Previous = (append) ? PreviousText : null;
	PreviousText = (finaltxt) ? null : ThisText;
	PrimList.addElement(ThisText);
  }        
}
