import java.awt.Color;
import java.io.DataInput;
import java.io.IOException;

/**
 * CGM reader
 *
 * @author      (C) 1998 Berthold Daum (bdaum@online.de)
 * @version     1.5, 01/10/2001
 * @since       CGMView 0.4
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * 01/10/2001 bd moved readColor from BinRead and AsciRead to this class
 */

abstract class CgmReader extends Object implements Runnable{
  // Global params:
  CgmContext cgm=null;
  DataInput in=null;
  Color[] ColorTable=new Color[257];

  Thread ReaderThread=null;
  
  static final boolean DebugOutput=false;
  // Global status of the reader:
  Cgm ContextOrPicture;

  static final int COLOR_MODE_DIRECT=0;
  static final int COLOR_MODE_DIRECT_ALPHA=1;
  static final int COLOR_MODE_INDEXED=2;

  int ColorMode=COLOR_MODE_DIRECT_ALPHA;

  int  colr1 = 0, colg1 = 0, colb1 = 0;
  double  colr2 = 1, colg2 = 1, colb2 = 1;

public CgmReader() {
	super();
}
  final Color readColor() throws IOException {
	return readColor(ColorMode);
  }  
final Color readColor(int ColorMode) throws IOException {
	double r=0,g=0,b=0;
	int index;
	try {
	switch(ColorMode) {
	case COLOR_MODE_DIRECT_ALPHA:
	  r=readColorComp();
	  g=readColorComp();
	  b=readColorComp();
	  readColorComp();
	  break;
	case COLOR_MODE_DIRECT:
	  r=readColorComp();
	  g=readColorComp();
	  b=readColorComp();
	   break;
	case COLOR_MODE_INDEXED:
	  index=readInt();
	  try {
		Color c=ColorTable[index];
		if (c!=null) return c;
		break;
		}	
	  	catch (ArrayIndexOutOfBoundsException e) {
		  	return Color.red;
		  	}
	default:
	  System.out.println("Unknown Color Mode: "+ColorMode);
	  System.exit(1);
	}
	}
	catch (Exception e) { return null;}
	if (ContextOrPicture.applet.inverseColor) {
		return new Color(255-(int)((r-colr1)*colr2),255-(int)((g-colg1)*colg2),255-(int)((b-colb1)*colb2));
	}
	return new Color((int)((r-colr1)*colr2),(int)((g-colg1)*colg2),(int)((b-colb1)*colb2));
  }                      
  abstract protected double readColorComp() throws Exception;            
abstract void readElement() throws IOException;
/**
 * Insert the method's description here.
 * Creation date: (02.10.2001 11:04:48)
 */
abstract protected int readInt() throws Exception;
	public final void run() {
	try { 
	  readElement();
	}
	catch(IOException e) { System.out.println("Error reading CGM:"+e); }
  }  
final static double toAngle(double x, double y) {
	if (y == 0) return (x < 0) ? Math.PI : 0;
	if (x == 0) return (y < 0) ? -Math.PI/2 : Math.PI/2;
	return Math.atan(y/x);
}
 public final void waitFor() {
	while (ReaderThread.isAlive()) {
	  try {
		if (ReaderThread.isAlive()) ReaderThread.join(1000);
	  }
	  catch (InterruptedException e) {}
	}
  }  
}
