/**
 * Oval object
 *
 * @author      (C) 1998 Berthold Daum (bdaum@online.de)
 * @version     1.4, 14/01/01
 * @since       CGMView 0.5
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * 14-01-01 bd fixed problem for linewidth > 1
 */

class CgmOval extends CgmPrimitive {

CgmOval (double cx,double cy,double r,double r2) {
	x = cx;
	y = cy;
	Width = Math.abs(r);
	Height = Math.abs(r2);
}
final void draw(java.awt.Graphics g,double w, double h, boolean fill)  {

	int x1 =  (int) (x*w+H6);
	int y1 =  (int) (y*h+H6);
	int rx1 =  (int) (Width*w+H6);
	int ry1 =  (int) (Height*h+H6);
	if ((fill) && (IntStyle >= 1)) {
		g.setColor(FillColor);
		g.fillOval(x1-rx1,y1-ry1,rx1<<1,ry1<<1);
	}
	if (LineColor != null) {
	 	g.setColor(LineColor);
		int lw=(int) (LineWidth*w+H5);
		if (lw<=1) {
	  		g.drawOval(x1-rx1,y1-ry1,rx1<<1,ry1<<1); //standard oval for linewidth <= 1
	  		return;
		}
		rx1 = rx1<<1+lw;	// multiple ovals for linewidth > 1
		ry1 = ry1<<1+lw;
		x1 -= rx1>>1;
		y1 -= ry1>>1;
		for(int i=1; i<=lw; i++) {
	  		g.drawOval(x1, y1, rx1, ry1);
	  		if(i<lw) {
				g.drawOval(x1,   y1,   --rx1, --ry1);
				g.drawOval(x1+1, y1,   rx1, ry1);
				g.drawOval(x1,   ++y1, rx1, ry1);
				g.drawOval(++x1, y1, rx1--, ry1--);
	  		}
		}
	}
}
final boolean find (double x, double y) {
	if ((visibility == HIDDEN) || (IntStyle < 1)) return false;
	double a= Width/2;
	double b= Height/2;
	double a1= (x-this.x-a)/a;
	double b1= (y-this.y-b)/b;
	return (a1*a1+b1*b1 <= 1);
}
}
