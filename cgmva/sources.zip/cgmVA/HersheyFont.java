/*****************************************************************************/
//
//  Copyright (c) James P. Buzbee 1996
//  House Blend Software
//
//  jbuzbee@nyx.net
//  Version 1.1 Dec 11 1996
//  Version 1.2 Sep 18 1997
//  Version 1.3 Feb 28 1998
//
// Permission to use, copy, modify, and distribute this software
// for any use is hereby granted provided
// this notice is kept intact within the source file
// This is freeware, use it as desired !
//
// Very loosly based on code with authors listed as :
// Alan Richardson, Pete Holzmann, James Hurt
//
// **** changes /bd Nov98
//
// -made fontAdjustment case independent
// -added another constructor HersheyFont(InputStream,String)
// -added private method getTextLength(Float,String)
// -added public method getTextLength(String)
// -changed to BufferedInputStream in LoadHersheyFont
// -made allocation of vertices dynamic in LoadHersheyFont
//
// **** changes /bd Dec98
//
// -simplified exception handling
//
// **** changes /bd Jan01
//
// -removed some superfluous statements
//
// change /bd Oct01
//
// -fixed incompatibility with MS JVM (implicit char->int cast in comparison)
//
// change /bd Dec05
//
// -fixed array bound exception when character code was outside character set of font
// -allowed for fonts with more than 256 characters
/*****************************************************************************/

import java.awt.*;
import java.io.*;
import java.net.URL;

/** *************************************************************************** */

public class HersheyFont extends java.lang.Object {
    public final static int HORIZONTAL_CENTER = 0;

    public final static int HORIZONTAL_LEFT = 1;

    public final static int HORIZONTAL_RIGHT = 2;

    public final static int HORIZONTAL_NORMAL = 1;

    public final static int VERTICAL_TOP = 0;

    public final static int VERTICAL_HALF = 1;

    public final static int VERTICAL_CAP = 2;

    public final static int VERTICAL_BOTTOM = 3;

    public final static int VERTICAL_NORMAL = 3;

    private final static int MAX_CHARACTERS = 256;

    protected final static int X = 0;

    protected final static int Y = 1;

    private float hersheyWidth = 1;

    private float hersheyHeight = 1;

    private int hersheyLineWidth = 1;

    private int hersheyHorizontalAlignment = HORIZONTAL_NORMAL;

    private int herhseyVerticalAlignment = VERTICAL_NORMAL;

    private double hersheyTheta = 0;

    private boolean hersheyItalics = false;

    private float hersheyItalicSlant = 0.75f;

    private String copyright = "Copyright (c) James P. Buzbee Mar 30, 1996";

    private float H5 = 0.5f;

    protected String name;

    protected char characterVectors[][][] = new char[MAX_CHARACTERS][][];

//    protected int numberOfPoints[] = new int[MAX_CHARACTERS]; // bd Dec 15, 2005

    protected int characterMinX[];

    protected int characterMaxX[];

    protected int characterSetMinY;

    protected int characterSetMaxY;

    protected int charactersInSet;

    /** *************************************************************************** */
    public HersheyFont(InputStream fontStream, String fontName) {
        name = fontName;

        // load the font file
        LoadHersheyFont(fontName, fontStream);

    }

    /** *************************************************************************** */
    public HersheyFont(String fontName) {
        name = fontName;
        try {
            // open the font file
            InputStream fontStream = new FileInputStream(fontName);

            // load the font file
            LoadHersheyFont(fontName, fontStream);

            // close the font file
            fontStream.close();

        } catch (IOException e) {
            System.out.println(e);
        }
    }

    /** *************************************************************************** */
    public HersheyFont(URL base) {
        name = base.toString();

        try {
            // open the font file
            InputStream fontStream = base.openStream();

            // load the font file
            LoadHersheyFont(name, fontStream);

            // close the font file
            fontStream.close();
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    /** *************************************************************************** */
    public HersheyFont(URL base, String fontName) {
        name = fontName;

        try {
            // open the font file
            InputStream fontStream = new URL(base, fontName).openStream();

            // load the font file
            LoadHersheyFont(fontName, fontStream);

            // close the font file
            fontStream.close();
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    /** ********************************************************************************** */
    protected void calculateCharacterSize(int j, int xadj) {
        characterMinX[j] = 1000;
        characterMaxX[j] = -1000;

        // for all the vertices in the character
        for (int i = 1; i < characterVectors[j][X].length; i++) {  // bd, Dec 15, 2005
            // if this is not a "skip"
            if (characterVectors[j][X][i] != ' ') {
                int cx = characterVectors[j][X][i];
                int cy = characterVectors[j][Y][i];
                // if this is less than our current minimum
                if (cx < characterMinX[j]) {
                    // save it
                    characterMinX[j] = cx;
                }

                // if this is greater than our current maximum
                if (cx > characterMaxX[j]) {
                    // save it
                    characterMaxX[j] = cx;
                }

                // if this is less than our current minimum
                if (cy < characterSetMinY) {
                    // save it
                    characterSetMinY = cy;
                }

                // if this is greater than our current maximum
                if (cy > characterSetMaxY) {
                    // save it
                    characterSetMaxY = cy;

                }
            }
        }

        characterMinX[j] -= xadj;
        characterMaxX[j] += xadj;
    }

    /** *************************************************************************** */

    protected void drawCharacter(int xp, int yp, int rotpx, int rotpy,
            float width, float height, boolean rotate, float sinTheta,
            float cosTheta, boolean Draw, Rectangle r, char Vectors[][],
            int minX, int characterSetMinY, // bd Dec 15, 2005
            boolean Italics, float slant, Graphics g) {
        float xd, yd, xd2, yd2;
        int oldx = 0, oldy = 0, x, y, i;
        boolean skip = true;
        // int thisCharacterMinX;
        // int thisCharacterMaxX;
        float finalSlant = height * (-slant);

        // loop through each vertex in the character

        for (i = 1; i < Vectors[X].length; i++) { // bd Dec 15, 2005
            // if this is a "skip"
            if (Vectors[X][i] == ' ') {
                // set the skip flag
                skip = true;
            } else {
                // calculate italics offset if necessary
                x = (int) ((Italics) ? ((Vectors[Y][i] - characterSetMinY) * finalSlant)
                        : 0)
                        +
                        // add italics offset to the "normal" point
                        // transformation
                        // transformX (xp, Vectors[X][i], minX, width);
                        ((int) (xp + (Vectors[X][i] - minX) * width));

                // calculate the y coordinate
                // y = transformY (yp, Vectors[Y][i] , characterSetMinY,
                // height);
                y = ((int) (yp + (Vectors[Y][i] - characterSetMinY) * height));

                // if we are doing a rotation
                if (rotate) {
                    // apply the rotation matrix ...

                    // transform the coordinate to the rotation center point
                    xd = (x - rotpx);
                    yd = (y - rotpy);
                    // if (i==1) System.out.println("x,rotx,xd"+x+" "+y+"
                    // "+rotpx+" "+rotpy+" "+xd+" "+yd);

                    // rotate
                    xd2 = xd * cosTheta - yd * sinTheta;
                    yd2 = xd * sinTheta + yd * cosTheta;

                    // transform back
                    x = (int) (xd2 + H5) + rotpx;
                    y = (int) (yd2 + H5) + rotpy;

                }

                if (!Draw) {
                    // System.out.println("x,y" + x + ", " + y );

                    // we just want the bounding box of the string
                    if (x < r.x) {
                        r.x = x;
                    }
                    if (y < r.y) {
                        r.y = y;
                    }

                    if (x > r.width) {
                        r.width = x;
                    }
                    if (y > r.height) {
                        r.height = y;
                    }
                }

                if (!skip) {
                    // if we are to draw the string
                    if (Draw) {
                        drawFontLine(oldx, oldy, x, y, hersheyLineWidth, g);
                    }
                } // end if not skip

                skip = false;

                oldx = x;
                oldy = y;

            } // end if skip
        } // end for each vertex in the character
    }

    /** *************************************************************************** */

    protected void drawFontLine(int x1, int y1, int x2, int y2, int width,
            Graphics g) {
        // if the width is greater than one
        if (width > 1) {
            Polygon filledPolygon = new Polygon();

            int offset = width >> 1;

            // this does not generate a true "wide line" but it seems to
            // look OK for font lines

            filledPolygon.addPoint(x1 - offset, y1 + offset);
            filledPolygon.addPoint(x1 + offset, y1 - offset);
            filledPolygon.addPoint(x2 + offset, y2 - offset);
            filledPolygon.addPoint(x2 - offset, y2 + offset);

            // draw a polygon
            g.fillPolygon(filledPolygon);
        } else {
            // draw a line
            g.drawLine(x1, y1, x2, y2);
            // System.out.println("" + x1 + " " + x2 );
        }
    }

    /** *************************************************************************** */

    public void drawString(String text, int x, int y, Graphics g) {
        drawText(text, x, y, hersheyWidth, hersheyHeight,
                hersheyHorizontalAlignment, herhseyVerticalAlignment,
                hersheyTheta, true, new Rectangle(), g);
        return;
    }

    /** *************************************************************************** */

    protected int drawText(String text, int xc, int yc, float width,
            float height, int Horizontal_Alignment, int Vertical_Alignment,
            double theta, boolean Draw, Rectangle r, Graphics g) {

        int character;
        int len;
        int rotpx = 0, rotpy = 0;
        int xp, yp;
        boolean rotate = false;
        float cosTheta = 0, sinTheta = 0;
        float verticalOffsetFactor = 0;

        // set the flag to true if the angle is not 0.0
        rotate = (theta != 0.0) ? true : false;

        // if we are to do a rotation
        if (rotate) {
            // set up the rotation variables
            theta = -Math.PI / 180.0 * theta;
            cosTheta = (float) Math.cos(theta);
            sinTheta = (float) Math.sin(theta);

            // set the position to do all rotations about
            rotpx = xc;
            rotpy = yc;
        }

        // starting position
        xp = xc;

        yp = yc;

        // if we are not going to actually draw the string
        if (!Draw) {
            // set up to initialize the bounding rectangle
            r.x = xp;
            r.y = yp;
            r.width = xp;
            r.height = yp;
        }

        switch (Vertical_Alignment) {
        case VERTICAL_TOP:
            verticalOffsetFactor = 0;
            break;

        case VERTICAL_HALF:
            verticalOffsetFactor = 0.5f;
            break;

        case VERTICAL_NORMAL: // also VERTICAL_BOTTOM

            verticalOffsetFactor = 1;
            break;

        case VERTICAL_CAP:
            verticalOffsetFactor = 0.25f;
            break;

        }

        // move the y position based on the vertical alignment
        yp -= (int) (verticalOffsetFactor * (height * (characterSetMaxY - characterSetMinY)));

        // if we have a non-standard horizontal alignment
        if ((Horizontal_Alignment != HORIZONTAL_LEFT)
                && (Horizontal_Alignment != HORIZONTAL_NORMAL)) {
            // find the length of the string in pixels ...
            len = getTextLength(width, text);

            // if we are center aligned
            if (Horizontal_Alignment == HORIZONTAL_CENTER) {
                // move the starting point half to the left
                xp -= len >> 1;
            } else {
                // alignment is right, move the start all the way to the left
                xp -= len;
            }
        }

        // loop through each character in the string ...
        for (int j = 0; j < text.length(); j++) {
            // the character's number in the array ...
            character = text.charAt(j) - ' ';
            // bd Dec 15, 2005 : Fold back to lower part of codetable if font
            // defines only lower part
            if (character >= charactersInSet) {
                if (character < 256)
                    character -= 128;
                if (character >= charactersInSet)
                    character = 0;
            }
            if (character < 0)
                character = 0;
            // render this character
            drawCharacter(xp, yp, rotpx, rotpy, width, height, rotate,
                    sinTheta, cosTheta, Draw, r, characterVectors[character],
                    characterMinX[character], // bd Dec 15, 2005
                    characterSetMinY, hersheyItalics, hersheyItalicSlant, g);

            // advance the starting coordinate
            xp += (int) ((characterMaxX[character] - characterMinX[character]) * width);

        } // end for each character

        return (0);
    }

    /** *************************************************************************** */
    protected int fontAdjustment(String fontname) {
        int xadjust = 0;

        // if we do not have a script type font
        if (fontname.toLowerCase().indexOf("scri") < 0) {
            // if we have a gothic font
            if (fontname.toLowerCase().indexOf("goth") >= 0) {
                xadjust = 2;
            } else {
                xadjust = 3;
            }
        }

        return (xadjust);

    }

    /** ************************************************************************** */

    private int getInt(InputStream file, int n) throws IOException {
        char[] buf;
        int c;
        int j = 0;

        buf = new char[n];

        // for the specified number of characters
        for (int i = 0; i < n; i++) {
            c = file.read();

            // get character and discard spare newlines
            while ((c == '\n') || (c == '\r')) {
                c = file.read();
            }

            // if we hit end of file
            if (c == -1) {
                // return an error
                return (c);
            }

            // if this is not a blank
            if ((char) c != ' ') {
                // save the character
                buf[j++] = (char) c;
            }
        }

        // return the decimal equivilent of the string
        return (Integer.parseInt(String.copyValueOf(buf, 0, j)));

    }

    /** *************************************************************************** */
    public String getName() {
        return (name);
    }

    /**
     * This method was created in VisualAge.
     * 
     * @return int
     * @param width
     *            float
     * @param text
     *            java.lang.String
     */
    private int getTextLength(float width, String text) {
        // find the length of the string in pixels ...
        float len = 0;

        for (int j = 0; j < text.length(); j++) {
            // the character's number in the array ...
            int character = text.charAt(j) - ' ';
            // bd Dec 15, 2005 : Fold back to lower part of codetable if font
            // defines only lower part
            if (character >= charactersInSet) {
                if (character < 256)
                    character -= 128;
                if (character >= charactersInSet)
                    character = 0;
            }
            if (character < 0)
                character = 0;
            len += (characterMaxX[character] - characterMinX[character])
                    * width;
        }
        return (int) len;
    }

    public int getTextLength(String text) {
        return getTextLength(hersheyWidth, text);

    }

    /** *************************************************************************** */

    private void LoadHersheyFont(String fontname, InputStream fs) {
        BufferedInputStream fontStream = new BufferedInputStream(fs);
        int character = 0, n, c;
        int xadjust = fontAdjustment(fontname);

        try {
            // loop through the characters in the file ...
            // while we have not processed all of the characters
            while (true) {
                // if we cannot read the next field
                if (getInt(fontStream, 5) < 1) 
                {
                    // we are done, set the font specification for num chars
                    charactersInSet = character;

                    // break the read loop
                    break;
                }
                if (character == characterVectors.length) { // bd, Dec15, 2005
                    char[][][] newVec = new char[character*2][][];
                    System.arraycopy(characterVectors, 0, newVec, 0, character);
                    characterVectors = newVec;
                }
                // get the number of vertices in this character
                n = getInt(fontStream, 3);
                characterVectors[character] = new char[2][n];
                // save it
//                numberOfPoints[character] = n; // bd Dec 15, 2005
                // read in the vertice coordinates ...
                for (int i = 0; i < n; i++) {
                    // if we are at the end of the line
                    if ((i == 32) || (i == 68) || (i == 104) || (i == 140)) {
                        // skip the carriage return
                        fontStream.read();
                    }
                    // get the next character
                    c = fontStream.read();
                    // if this is a return ( we have a DOS style file )
                    if (c == '\n') {
                        // throw it away and get another
                        c = fontStream.read();
                    }
                    // get the x coordinate
                    characterVectors[character][X][i] = (char) c;
                    // read the y coordinate
                    characterVectors[character][Y][i] = (char) fontStream
                            .read();
                }
                // skip the carriage return
                fontStream.read();
                // increment the character counter
                character++;
            }
            // determine the size of each character ...

            characterMinX = new int[charactersInSet];
            characterMaxX = new int[charactersInSet];

            // initialize ...
            characterSetMinY = 1000;
            characterSetMaxY = -1000;

            // loop through each character ( except the space character )
            for (int j = 1; j < charactersInSet; j++) {
                // calculate the size
                calculateCharacterSize(j, xadjust);
            }

            // handle the space character - if the 'a' character is defined
            if (('a' - ' ') <= charactersInSet) {
                // make the space character the same size as the 'a'
                characterMinX[0] = characterMinX['a' - ' '];
                characterMaxX[0] = characterMaxX['a' - ' '];
            } else {
                // make the space char the same size as the last char
                characterMinX[0] = characterMinX[charactersInSet - 1];
                characterMaxX[0] = characterMaxX[charactersInSet - 1];
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    /** *************************************************************************** */
    public void setHeight(float height) {
        hersheyHeight = height;
    }

    /** *************************************************************************** */
    public void setHorizontalAlignment(int alignment) {
        hersheyHorizontalAlignment = alignment;
    }

    /** *************************************************************************** */
    public void setItalics(boolean flag) {
        hersheyItalics = flag;
    }

    /** *************************************************************************** */
    public void setItalicsSlant(float slant) {
        hersheyItalicSlant = slant;
    }

    /** *************************************************************************** */
    public void setLineWidth(int width) {
        hersheyLineWidth = width;
    }

    /** *************************************************************************** */

    public void setRotation(double theta) {
        hersheyTheta = theta;
    }

    /** *************************************************************************** */
    public void setVerticalAlignment(int alignment) {
        herhseyVerticalAlignment = alignment;
    }

    /** *************************************************************************** */
    public void setWidth(float width) {
        hersheyWidth = width;
    }

    /** *************************************************************************** */

    public Rectangle stringLimit(String text, int x, int y, Graphics g) {
        Rectangle r = new Rectangle();
        drawText(text, x, y, hersheyWidth, hersheyHeight,
                hersheyHorizontalAlignment, herhseyVerticalAlignment,
                hersheyTheta, false, r, g);

        r.width = r.width - r.x + 1;
        r.height = r.height - r.y + 1;
        return (r);
    }

    /** *************************************************************************** */

    public String toString() {
        return (name);
    }
}
