/**
 * Text object
 *
 * @author      � 1998,1999 Berthold Daum (bdaum@online.de)
 * @version     1.5, 01/10/2001
 * @since       CGMView 0.1
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Changes:
 * 16-11-98: Support for underlined text added. bd
 * 14-1-2001: added find(String,int). bd
 * 01-10-2001: fall back to built-in Hershey font if CharOri != 0
 */
import java.awt.*;

public class CgmText extends CgmPrimitive {
	String Content;
	int TextAlignHor;
	int state = 0;
	HersheyFont hf = null;
	CgmViewApplet applet;
	double CharacterExpansion = 1.0;
	double CharacterSpacing = 0.0;
	double CharacterHeight;
	double as=0,ac=1,aa=0;
	double extW=0,extH=0;
	int TextPath;
	double CharOri;
	double CharSlant;
	boolean underlined;
	boolean selected;
	String fontname;
	int style;
	int xe = 0;
	int ye = 0;
	CgmText Previous;

CgmText (double ex, double ey, double cx, double cy,double h,double a, double s, double spacing,String str,int horA, int vertA, int path) {
	CharacterHeight = h;
	TextAlignHor = horA;
	TextPath = path;
	if (horA == 0) {
		switch (path) {
		case 1:
			TextAlignHor = 3;
			break;
		case 2:
			TextAlignHor = 2;
			break;
		default:
			TextAlignHor = 1;
		}
	}
	if (vertA == 0) vertA = (path == 4) ? 1 : 4;
	double Off = (9-2*vertA)*h/8;
	CharOri = a;
	CharSlant = s;
	Height = h;
	Width = 2;
	noclip = ((path != 0) || (a != 0));
//	x = cx-Math.sin(a)*Off;
	x = cx+Math.sin(a)*Off;
	y = cy+Math.cos(a)*Off;
	extW = ex;
	extH = ey;
	Content = str;
	CharacterSpacing = spacing;
}
final void draw(java.awt.Graphics g,double w, double h, boolean fill){
float ch= (float) (CharacterHeight*h);
if ((FillColor != null) && (ch > 1)) {
	Font fo = null;
	FontMetrics Metrics = null;
	Rectangle clip = null;
	int x1,y1,hOff;
	if (Previous != null) {
		x1=Previous.xe;
		y1=Previous.ye;
		this.extW = Previous.extW;
		this.extH = Previous.extH;
	} else {
		x1=(int) (x*w+H6);
		y1=(int) (y*h+H6);
	}
	g.setColor(FillColor);
	if (state==0) {
		if (applet.Fonts != null) {
			state=2;
			String fn=applet.fontname(fontname);
			if (((style & Font.BOLD) > 0) && ((style & Font.ITALIC) > 0) && ((hf = (HersheyFont) applet.Fonts.get(fn+"_BoldItalic")) != null)) style = Font.PLAIN;
			if (((style & Font.BOLD) > 0) && ((hf = (HersheyFont) applet.Fonts.get(fn+"_Bold")) != null)) style -= Font.BOLD;
			if (((style & Font.ITALIC) > 0) && ((hf = (HersheyFont) applet.Fonts.get(fn+"_Italic")) != null)) style -= Font.ITALIC;
			if (hf == null) hf = (HersheyFont) applet.Fonts.get(fn);
 		    if ((hf == null) && (CharOri != 0)) {
			   hf = (HersheyFont) applet.Fonts.get("FUTURAL");
 		       }
			}
		if (hf == null) {
			CharOri = 0;
			state = 1;
		} else {
			as = Math.sin(CharOri);
			ac = Math.cos(CharOri);
			aa = CharOri*180/Math.PI;
		}
	}
	if (state==1) {
		g.setFont(fo = new Font(fontname,(style & (~128)),(int) ch));
		Metrics = g.getFontMetrics(fo);
		if (extW > 0) {
			ch = ch*(float)(extH*h/(Metrics.getMaxDescent()+Metrics.getMaxAscent()));
			g.setFont(fo = new Font(fontname,(style & (~128)),(int) ch));
			Metrics = g.getFontMetrics(fo);
		}
		
	} else {
		hf.setHeight(ch/26);
		hf.setWidth((float)(CharacterExpansion*ch/26));
		hf.setItalics ((style & Font.ITALIC) > 0);
		if (Math.abs(CharSlant) > 0.05) {
			hf.setItalics(true);
			hf.setItalicsSlant((float) CharSlant);
		} else hf.setItalicsSlant(0.75f);
		hf.setLineWidth (((style & Font.BOLD) > 0) ? 2 : 1);
		hf.setRotation(aa);
	}
	if (extW > 0) {
		clip = g.getClipRect();
		int w1 = (int)(extW*w+H5);
		int e1 = x1;
		switch (TextAlignHor) {
			case 2: e1 -= w1>>1;
					break;
			case 3: e1 -= w1;
		}
		g.clipRect(e1,(int)(y1-((state==1) ? Metrics.getAscent() : ch)),w1,(int) (extH*h));
	}
	int textwidth = (state==1) ? Metrics.stringWidth(Content) :	hf.getTextLength(Content);
	int l = Content.length();
	double cw = (textwidth*CharacterSpacing/l);
	textwidth += (int)((l-1)*cw);
	switch (TextPath) {
		case 1:
			textwidth=-textwidth;
			break;
		case 2:
		case 3:
			textwidth /= l;
	}
	switch (TextAlignHor) {
		case 2: hOff = textwidth>>1;
				break;
		case 3: hOff = textwidth;
				break;
		default: hOff = 0;
	}
	x1 -= (int)(ac*hOff);
	y1 += (int)(as*hOff);
	if ((CharacterSpacing != 0) || (TextPath > 0)) {
		String s;
		double sw = 0;
		xe = x1;
		ye = y1;
		for (int i=0;i<l;i++) {
			s = Content.substring(i,i+1);
			sw = (TextPath < 2) ? cw + ( (state==1) ? Metrics.stringWidth(s) : hf.getTextLength(s)) : -(cw+ch);
			if ((TextPath == 1) || (TextPath == 2)) {
				xe -= (int)(sw*ac);
				ye += (int)(sw*as);
			}
			if (state==1) 
				g.drawString(s,xe,ye);
			else
				hf.drawString (s,xe,ye,g);
			if ((TextPath == 0) || (TextPath == 3)) {
				xe += (int)(sw*ac);
				ye -= (int)(sw*as);
			}
		}
	} else {
		if (state==1)
			g.drawString(Content,x1,y1);
		else {
			hf.drawString (Content, x1, y1, g);
		}
		xe = x1+ (int) (ac*textwidth);
		ye = y1+ (int) (as*textwidth);
	}
	if (selected) {
		g.setColor(Color.red);
		y1 += 2;
	 	CgmPolygon.drawLine(g,x1+(int)(as*(l = (int) (ch*0.05+H5))), y1+(int)(ac*l), x1+(int)(ac*textwidth+as*l), y1+(int)(ac*l-as*textwidth),4);
	}
	else if (underlined)
	  	g.drawLine(x1+(int)(as*(l = (int) (ch*0.05+H5))), y1+(int)(ac*l), x1+(int)(ac*textwidth+as*l), y1+(int)(ac*l-as*textwidth));
	if (extW > 0) g.setClip(clip);
}
}
final int find (String t,int m) {
	if (m == -2)
	{
		if (selected)
		{
			selected = false;
			return -1;
		}
		return m;
	}
	if (m == -1)
	{ if (Content.toUpperCase().indexOf(t.toUpperCase()) >= 0) 
		{
			selected = true;
			return 0;
		}
	}
	selected = false;
	return m;
}
/**
 * This method was created in VisualAge.
 * @param f java.awt.Font
 */
final void setFont(Font f) {
	fontname = f.getName();
	style = f.getStyle();
	underlined = ((style & 128) > 0);
	style = style & (~128);
}
}
