/**
 * CGM viewer Applet
 *
 * @author 		� 1996 Alexander Larsson (alla@lysator.liu.se)
 * @author      � 1998-2002 Berthold Daum (bdaum@online.de)
 * @version     1.10, 23.02.2006
 * @since       CGMView 0.1
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * changes 14-1-2001: added findText, getZoom, getLayer, setZoomFactor, getZoomFactor
 *                          zoom(int), setModifiers, getX(int,String,int), getY(int,String,int)
 *                          scroll,hide(int,String,int), show(int,String,int),wire(int,String,int)
 *                          map(int,String,int)
 *                    added support for ZoomFactor applet parameter
 *                    added Centre mouse action (Shift + click)
 *                    added JavaScript event handler (parameter eventHandler)
 * changes 01-10-2001: fixed bgColor problem
 *                     new parameter inverse
 * changes 09-11-2001: fixed problem with gif images
 * changes 23-11-2002: added keyActions
 *                     added showHotspots
 *                     fixed problems with imagemaps
 * changes 06-04-2006: added methods getViewX, getViewY, getViewWith, getViewHeight
 */
import java.applet.*;
import java.awt.*;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.util.*;
import java.util.zip.*;
import java.net.*;
import java.io.*;
import netscape.javascript.*;
import java.awt.event.*; 


public class CgmViewApplet extends Applet implements MouseListener, MouseMotionListener {
    String appletVersion = "1.9.1";

    Image offScrImage = null;

    Image offScreenBuffer = null;

    Thread UpdateThread = null;

    String filename;

    Hashtable cgmFiles = new Hashtable();

    Layer[] Layers = new Layer[17]; // Layer 16 for internal use

    Color BackColor = null;

    boolean keyActions = false;

    boolean dragged = false;

    boolean leftmouse = true;

    boolean ani = false;

    boolean splash = true;

    boolean inverseColor = false;

    int mouseX;

    int mouseY;

    int currX;

    int currY;

    double factor = 100;

    double userFactor = 1;

    double zoomFactor = Math.sqrt(2.0);

    int canvasWidth;

    int canvasHeight;

    int origWidth;

    int origHeight;

    int origX;

    int origY;

    int canvasX = 0;

    int canvasY = 0;

    int keyMod = 0;

    int Width;

    int Height;

    String BaseControls = "Click/Drag=Zoom in, AltClick=Zoom out, AltDrag=Pan, AltDoubleClick=Reset, ShiftClick=Centre";

    String Controls = "";

    URL ImageBase = null;

    URL SoundBase = null;

    URL FontBase = null;

    double clipX = 0;

    double clipY = 0;

    double clipW = 1;

    double clipH = 1;

    String AnimationEvent = "";

    int AnimationMouseX;

    int AnimationMouseY;

    int AnimationCurrX;

    int AnimationCurrY;

    int AnimationModifier;

    int AnimationMask = 2;

    int ModifiersSet = 0;

    boolean ModifierOnce = true;

    String AnimationClickPicture = null;

    String AnimationDragPicture = null;

    double AnimationFactorX = 1;

    double AnimationFactorY = 1;

    double AnimationOffX = 0;

    double AnimationOffY = 0;

    int ComponentFound = -1;

    int ClickComponent = -1;

    int DragComponent = -1;

    RenderThread renderer;

    Hashtable zipFiles = null;

    MediaTracker tracker = null;

    LayerElement LastElementFound = null;

    int LayerFound = -1;

    int ClickLayer = -1;

    int DragLayer = -1;

    Hashtable Fonts = null;

    Hashtable Sounds = null;

    Vector urls = null;

    int hotspot = -1;

    boolean showHotspots = false;

    LayerElement mapElement = null;

    URL targetURL = null;

    boolean announce = false;

    int key = 0;

    int kmod = 0;

    String Searchkey = null;

    int SearchLayer = -1;

    String JSmethod = "appletEvent";

    String JSmsg[] = new String[3];

    JSObject JSwin = null;

    /**
     * Constructor
     */
    public CgmViewApplet() {
        super();
        addComponentListener(new ComponentListener() {

            public void componentHidden(ComponentEvent arg0) {
            }

            public void componentShown(ComponentEvent arg0) {
            }

            public void componentMoved(ComponentEvent arg0) {
            }

            public void componentResized(ComponentEvent arg0) {
                initCanvas();
                repaint();
            }

        });
    }

    protected final void addFont(String filename) {
        String fn = filename;
        if (fn.indexOf(".") < 0)
            fn = fn + ".jhf";
        String sn = fontname(fn);
        if (this.Fonts == null)
            this.Fonts = new Hashtable();
        if ((zipFiles == null) || (zipFiles.get(fn.toUpperCase()) == null)) {
            if (announce)
                showStatus("Loading font..." + fn);
            this.Fonts.put(sn, new HersheyFont(FontBase, fn));
        }
    }

    /**
     * Set clipping rectangle for scene
     * 
     * @param x
     *            double (0..1000)
     * @param y
     *            double (0..1000)
     * @param Width
     *            double (0..1000)
     * @param Height
     *            double (0..1000)
     */
    public final void clip(double x, double y, double Width, double Height) {
        clipX = x * 0.001;
        clipY = y * 0.001;
        clipW = Width * 0.001;
        clipH = Height * 0.001;
    }

    /**
     * Set clipping rectangle for layer
     * 
     * @param layer
     *            int (0..15)
     * @param x
     *            double (0..1000)
     * @param y
     *            double (0..1000)
     * @param Width
     *            double (0..1000)
     * @param Height
     *            double (0..1000)
     */
    public final void clip(int layer, double x, double y, double Width,
            double Height) {
        Layer l = getLayer(layer);
        l.clipx = Math.round(x * 0.001);
        l.clipy = Math.round(y * 0.001);
        l.clipw = Math.round(Width * 0.001);
        l.cliph = Math.round(Height * 0.001);
    }

    public void destroy() {
        if ((UpdateThread != null) && (UpdateThread.isAlive())) {
            UpdateThread.stop();
        }
        UpdateThread = null;
    }

    private final int drawString(Graphics g, int x, int y, String txt,
            int style, int size, Color col, int align) {
        Font fo = new Font("Arial", style, size);
        g.setFont(fo);
        g.setColor(col);
        int x2 = x;
        int l = g.getFontMetrics(fo).stringWidth(txt);
        switch (align) {
        case 2:
            x2 -= l;
            break;
        case 3:
            x2 -= (l / 2);
        }
        g.drawString(txt, x2, y);
        return x2 + l;
    }

    /**
     * Find picture at position
     * 
     * @return java.lang.String
     * @param x
     *            int (0..1000)
     * @param y
     *            int (0..1000)
     */
    // Removed due to compatibility problems with EcmaScript (Methode clashes
    // with findPicture(int, String)
    // public final String findPicture(double x, double y) {
    // return findPicture(-1, x, y);
    // }
    /**
     * Find picture at position in layer
     * 
     * @return java.lang.String
     * @param layer
     *            l (-1..15) (use -1 to search in all layers)
     * @param x
     *            int (0..1000)
     * @param y
     *            int (0..1000)
     */
    public final String findPicture(int layer, double x, double y) {
        if (this.isActive()) {
            double x1 = origX - canvasX;
            double y1 = origY - canvasY;
            double f1 = factor * userFactor;
            LastElementFound = null;
            LayerFound = -1;
            for (int i = 15; i >= 0; i--) {
                if ((layer < 0) || (i == layer)) {
                    Layer l = Layers[i];
                    if (l != null) {
                        LastElementFound = l.find(x1, y1, f1, f1,
                                (x / 1000 * factor), (y / 1000 * factor));
                        if (LastElementFound != null) {
                            ComponentFound = LastElementFound.SearchResult;
                            LayerFound = i;
                            return LastElementFound.clonename;
                        }
                    }
                }
            }
        }
        ComponentFound = -1;
        return "";
    }

    /**
     * Find picture at event position in layer l
     * 
     * @return java.lang.String
     * @param layer
     *            l (0..15)
     * @param Event
     *            java.lang.String (Drag,Drop,Move,...)
     */
    public final String findPicture(int layer, String Event) {
        double f = 1000.0 / factor;
        if ((Event.equals("Drag")) || (Event.equals("Drop"))) {
            if (AnimationDragPicture == null) {
                AnimationDragPicture = findPicture(layer, AnimationCurrX * f,
                        AnimationCurrY * f);
                DragComponent = ComponentFound;
                DragLayer = LayerFound;
            }
            ComponentFound = DragComponent;
            LayerFound = ComponentFound;
            return AnimationDragPicture;
        }
        if (Event.equals("Move"))
            return findPicture(layer, AnimationCurrX * f, AnimationCurrY * f);
        if (AnimationClickPicture == null) {
            AnimationClickPicture = findPicture(layer, AnimationMouseX * f,
                    AnimationMouseY * f);
            ClickComponent = ComponentFound;
            ClickLayer = LayerFound;
        }
        ComponentFound = ClickComponent;
        LayerFound = ClickLayer;
        return AnimationClickPicture;
    }

    /**
     * Find picture at event position
     * 
     * @return java.lang.String
     * @param Event
     *            java.lang.String (Drag,Drop,Move,...)
     */
    public final String findPicture(String Event) {
        return findPicture(-1, Event);
    }

    /**
     * Find text in layer l
     * 
     * @return java.lang.String
     * @param layer
     *            l (0..15)
     * @param t
     *            java.lang.String (Searchkey)
     */
    public final String findText(int layer, String t) {
        if (t.length() > 0)
            return findText(layer, t, -1);
        if (Searchkey == null) {
            ComponentFound = -1;
            LayerFound = -1;
            return "";
        }
        return findText(SearchLayer, Searchkey, -2);
    }

    /**
     * Find text in layer l
     * 
     * @return java.lang.String
     * @param layer
     *            l (0..15)
     * @param t
     *            java.lang.String (Searchkey)
     */
    private final String findText(int layer, String t, int m) {
        LayerFound = -1;
        ComponentFound = -1;
        String n = "";
        if (this.isActive()) {
            double x1 = origX - canvasX;
            double y1 = origY - canvasY;
            double f1 = factor * userFactor;
            int mo = m;
            LastElementFound = null;
            Searchkey = t;
            SearchLayer = layer;
            for (int i = 15; i >= 0; i--) {
                if ((layer < 0) || (i == layer)) {
                    Layer l = Layers[i];
                    if (l != null) {
                        LastElementFound = l.find(t, mo);
                        if (LastElementFound != null) {
                            ComponentFound = LastElementFound.SearchResult;
                            LayerFound = i;
                            n = LastElementFound.clonename;
                        }
                        mo = l.SearchResult;
                    }
                }
            }
        }
        return n;
    }

    /**
     * Find text
     * 
     * @return java.lang.String
     * @param t
     *            Searchkey
     */
    public final String findText(String t) {
        return findText(-1, t);
    }

    final String fontname(String fn) {
        int ci = Math.max(Math.max(fn.lastIndexOf(":"), fn.lastIndexOf("/")),
                fn.lastIndexOf("\\"));
        if (ci >= 0)
            fn = fn.substring(++ci);
        if ((ci = fn.indexOf(".")) >= 0)
            fn = fn.substring(0, ci);
        return fn.toUpperCase();
    }

    public final String getAppletInfo() {
        return "CgmViewApplet " + appletVersion + " \n"
                + "� 1996 Alexander Larsson (alla@lysator.liu.se) \n"
                + "� 1998-2006 Berthold Daum (berthold.daum@bdaum.de)";
    }

    /**
     * get current X-position of CGM-file
     * 
     * @return int
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     */
    public final double getCgmX(int layer, String filename) {
        return getElement(layer, filename).x * 1000;
    }

    /**
     * get current Y-position of CGM-file
     * 
     * @return int
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     */
    public final double getCgmY(int layer, String filename) {
        return getElement(layer, filename).y * 1000;
    }

    /**
     * get component number of previous find operation
     * 
     * @return int
     */
    public final int getComponent() {
        return ComponentFound;
    }

    /**
     * get current X-position of component
     * 
     * @return int
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     */
    public final double getComponentX(int layer, String filename, int comp) {
        LayerElement e = getElement(layer, filename);
        CgmPrimitive c = e.cgm.findComponent(comp);
        if (c == null)
            return -1;
        return (e.x + c.x) * 1000;
    }

    /**
     * get current Y-position of component
     * 
     * @return int
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     */
    public final double getComponentY(int layer, String filename, int comp) {
        LayerElement e = getElement(layer, filename);
        CgmPrimitive c = e.cgm.findComponent(comp);
        if (c == null)
            return -1;
        return (e.y + c.y) * 1000;
    }

    private final LayerElement getElement(int layer, String filename) {

        CgmContext cgm;
        String id;
        int p = filename.indexOf("#");
        if (p > 0) {
            cgm = readFile(filename.substring(0, p));
            id = filename.substring(p + 1);
        } else {
            cgm = readFile(filename);
            id = "";
        }
        Layer l = getLayer(layer);
        LayerElement e = new LayerElement(cgm, id);
        int i = l.Images.indexOf(e);
        if (i >= 0)
            return (LayerElement) l.Images.elementAt(i);
        l.Images.addElement(e);
        return e;
    }

    public final int getKey() {
        int k = key;
        if (key > 0)
            key = 0;
        return k;
    }

    public final int getKeyModifier() {
        return kmod & 15;
    }

    /**
     * get layer number of previous find operation
     * 
     * @return int
     */
    public final int getLayer() {
        return LayerFound;
    }

    private final Layer getLayer(int layer) {
        waitFor();
        if (Layers[layer] == null)
            Layers[layer] = new Layer();
        return Layers[layer];
    }

    /**
     * get current X-position of layer
     * 
     * @return int
     * @param layer
     *            int (0..15)
     */
    public final double getLayerX(int layer) {
        return getLayer(layer).x * 1000;
    }

    /**
     * get current Y-position of layer
     * 
     * @return int
     * @param layer
     *            int (0..15)
     */
    public final double getLayerY(int layer) {
        return getLayer(layer).y * 1000;
    }

    /**
     * get modifier key of previous event
     * 
     * @return int
     */
    public final int getModifier() {
        return AnimationModifier;
    }

    public final String[][] getParameterInfo() {
        String pinfo[][] = {
                { "nosplash", "boolean", "Do not display splash screen" },
                { "controls", "string", "Text for status line" },
                { "imagebase", "url", "Image directory" },
                { "cgmArchive", "url", "Optional ZIP archive" },
                { "filename", "url", "Image(s) to draw" },
                { "fontbase", "url", "Font directory" },
                { "hersheyFonts", "url", "Font(s) to use" },
                { "soundbase", "url", "Sound directory" },
                { "sound", "url", "Sound file(s) to preload" },
                { "imagemap", "string", "Image map file plus targets" },
                { "showHotspots", "boolean", "Shows selected hotspots" },
                { "bgcolor", "color", "Default background color" },
                { "inverse", "boolean", "Inverse colors" },
                { "zoomFactor", "double", "Zoom step factor" },
                { "keyActions", "boolean", "Enable keys for zoom and pan" },
                { "eventHandler", "string", "JavaScript event handler" }, };
        return pinfo;
    }

    /**
     * get current X-position of scene
     * 
     * @return int
     */
    public final double getSceneX() {
        return AnimationCurrX * 1000.0 / factor;
    }

    /**
     * get current Y-position of scene
     * 
     * @return int
     */
    public final double getSceneY() {
        return AnimationCurrY * 1000.0 / factor;
    }

    private final AudioClip getSound(String filename) {
        String fn = filename;
        AudioClip aclp;
        if (fn.indexOf(".") < 0)
            fn = fn + ".au";
        if (Sounds == null)
            Sounds = new Hashtable();
        aclp = (AudioClip) Sounds.get(fn);
        if (aclp == null) {
            if (announce)
                showStatus("Loading sound..." + fn);
            aclp = getAudioClip(SoundBase, fn);
            Sounds.put(fn, aclp);
        }
        return aclp;
    }

    /**
     * get applet version string
     * 
     * @return String version
     */
    public final String getVersion() {

        return appletVersion;
    }

    /**
     * get current X-position of scene
     * 
     * @return int
     */
    public final double getX() {
        return getSceneX();
    }

    /**
     * get current X-position of layer
     * 
     * @return int
     * @param layer
     *            int (0..15)
     */
    public final double getX(int layer) {
        return getLayerX(layer);
    }

    /**
     * get current X-position of CGM-file
     * 
     * @return int
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     */
    public final double getX(int layer, String filename) {
        return getCgmX(layer, filename);
    }

    /**
     * get current X-position of component
     * 
     * @return int
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     */
    public final double getX(int layer, String filename, int comp) {
        return getComponentX(layer, filename, comp);
    }

    /**
     * get current Y-position of scene
     * 
     * @return int
     */
    public final double getY() {
        return getSceneY();
    }

    /**
     * get current Y-position of layer
     * 
     * @return int
     * @param layer
     *            int (0..15)
     */
    public final double getY(int layer) {
        return getLayerY(layer);
    }

    /**
     * get current Y-position of CGM-file
     * 
     * @return int
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     */
    public final double getY(int layer, String filename) {
        return getCgmY(layer, filename);
    }

    /**
     * get current Y-position of component
     * 
     * @return int
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     */
    public final double getY(int layer, String filename, int comp) {
        return getComponentY(layer, filename, comp);
    }

    /**
     * get current zoom factor
     */
    public final double getZoom() {
        return userFactor;
    }

    /**
     * get current zoom factor
     */
    public final double getZoomFactor() {
        return zoomFactor;
    }

    /**
     * hide layer
     * 
     * @param layer
     *            int (0..15)
     */
    public final void hide(int layer) {
        getLayer(layer).visibility = HIDDEN;
    }

    /**
     * Hide picture
     * 
     * @param layer
     *            int (0..15)
     * @param filenames
     *            java.lang.String
     */
    public final void hide(int layer, String filenames) {
        setAttr(layer, filenames, HIDDEN);
    }

    /**
     * Hide picture
     * 
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     * @param comp
     *            int
     */
    public final void hide(int layer, String filename, int comp) {
        setAttr(layer, filename, comp, HIDDEN);
    }

    public void init() {
rect1xco = 20; 
  rect1yco = 20; 
  rect1width = 100; 
  rect1height = 50; 

	addMouseListener(this); 
        UpdateThread = new Thread(this, "Update-Thread");
        Dimension d = this.size();
        Width = d.width;
        Height = d.height;
        factor = Math.min(Width, Height);
        splash = (getParameter("nosplash") == null);
        String k = getParameter("controls");
        if (k != null)
            BaseControls = k;
        Controls = BaseControls;
        String ZipArchive = getParameter("cgmArchive");
        String ib = getParameter("imagebase");
        if ((ib != null) && (ib.toLowerCase().endsWith(".zip"))) {
            int ci = ib.indexOf("/") + 1;
            ZipArchive = ib.substring(ci);
            ib = ib.substring(0, ci);
        }
        ImageBase = normBase(ib);
        SoundBase = normBase(getParameter("soundbase"));
        FontBase = normBase(getParameter("fontbase"));
        String filename = getParameter("sound");
        if (filename != null) {
            StringTokenizer st = new StringTokenizer(filename, ",");
            while (st.hasMoreTokens())
                getSound(st.nextToken());
        }
        if (ZipArchive != null) {
            if (ZipArchive.indexOf(".") < 0)
                ZipArchive = ZipArchive + ".zip";
            loadArchive(ZipArchive);
        }
        filename = getParameter("hersheyFonts");
        if (filename != null) {
            StringTokenizer st = new StringTokenizer(filename, ",");
            while (st.hasMoreTokens())
                addFont(st.nextToken());
        }
        filename = getParameter("bgcolor");
        if (filename != null) {
            BackColor = Color.decode(filename);
        }
        filename = getParameter("inverse");
        inverseColor = (filename != null);
        filename = getParameter("showHotspots");
        showHotspots = (filename != null);
        filename = getParameter("keyActions");
        if (filename != null) {
            keyActions = true;
        }
        filename = getParameter("zoomFactor");
        if (filename != null) {
            zoomFactor = Double.valueOf(filename).doubleValue();
        }
        filename = getParameter("eventHandler");
        if (filename != null) {
            JSmethod = filename;
        }
        filename = getParameter("filename");
        if (filename == null) {
            System.out.println("No files");
            System.exit(1);
        }
        tracker = new MediaTracker(this);
        show(0, filename);
        String links = getParameter("imagemap");
        if (links != null) {
            StringTokenizer st = new StringTokenizer(links, ",");
            urls = new Vector(20, 10);
            if (st.hasMoreTokens()) {
                mapElement = getElement(0, st.nextToken());
            }
            if (mapElement != null && mapElement.cgm != null) {
                mapElement.visibility = STEALTH;
                while (st.hasMoreTokens()) {
                    try {
                        filename = st.nextToken();
                        if (filename != "")
                            urls
                                    .addElement(new URL(getDocumentBase(),
                                            filename));
                        else
                            urls.addElement(null);
                    } catch (IOException e) {
                        System.out.println(e);
                        if (isActive())
                            showStatus(e + "!");
                    }
                }
            } else
                mapElement = null;
        }
        announce = true;
        try {
            JSwin = JSObject.getWindow(this);
        } catch (Throwable e) {
        }
        UpdateThread.start();
    }

    final void initCanvas() {
        if (offScrImage == null)
            offScrImage = createImage(Width, Height);
        canvasX = 0;
        canvasY = 0;
        canvasWidth = Width;
        canvasHeight = Height;
        // tracker = new MediaTracker(this);
        Layer l = Layers[0];
        for (int i = 0; i < l.Images.size(); i++) {
            LayerElement e = (LayerElement) l.Images.elementAt(i);
            CgmContext cgm = e.cgm;
            if (cgm != null) {
                cgm.finishReading();
                CgmPicture pic = (CgmPicture) cgm.pictures.firstElement();
                if (pic.Width != 0) {
                    if (BackColor == null)
                        BackColor = pic.BackColor;
                    factor = Math.min(Math.abs(Width / (pic.Width * pic.ax)),
                            Math.abs(Height / (pic.Height * pic.ay)));
                    canvasWidth = (int) (pic.Width * factor * pic.ax);
                    canvasHeight = (int) Math.abs(pic.Height * factor * pic.ay);
                    break;
                }
            }
        }
        origWidth = canvasWidth;
        origHeight = canvasHeight;
        origX = (Width - origWidth) / 2;
        origY = (Height - origHeight) / 2;
        clipW = (double) Width / (double) canvasWidth;
        clipH = (double) Height / (double) canvasHeight;
        for (int i = 0; i < 17; i++) {
            if (Layers[i] != null) {
                Layers[i].clipw = clipW;
                Layers[i].cliph = clipH;
            }
        }
    }

    public boolean keyDown(Event evt, int k) {
        kmod = evt.modifiers & 15;
        if (keyActions) {
            int slowIncX = Math.max(1, Width / 100);
            int slowIncY = Math.max(1, Height / 100);
            int fastIncX = Math.max(1, Width / 5);
            int fastIncY = Math.max(1, Height / 5);
            int operation = evt.key;
            double fo = userFactor;
            if ((kmod & Event.CTRL_MASK) != 0) {
                switch (operation) {
                case Event.LEFT:
                    operation = Event.HOME;
                    break;
                case Event.RIGHT:
                    operation = Event.END;
                    break;
                case Event.UP:
                    operation = Event.PGUP;
                    break;
                case Event.DOWN:
                    operation = Event.PGDN;
                    break;
                }
            }
            if (operation == Event.ENTER && targetURL != null) {
                getAppletContext().showDocument(targetURL);
                return true;
            }
            switch (operation) {
            case '+':
                userFactor = Math.min(16, userFactor * zoomFactor);
                canvasX = (int) ((canvasX + Width / 2 - origX) * userFactor
                        / fo - Width / 2 + origX);
                canvasY = (int) ((canvasY + Height / 2 - origY) * userFactor
                        / fo - Height / 2 + origY);
                break;
            case '-':
                userFactor = Math.max(1, userFactor / zoomFactor);
                canvasX = (int) ((canvasX + Width / 2 - origX) * userFactor
                        / fo - Width / 2 + origX);
                canvasY = (int) ((canvasY + Height / 2 - origY) * userFactor
                        / fo - Height / 2 + origY);
                break;
            case Event.LEFT:
                canvasX -= slowIncX;
                break;
            case Event.RIGHT:
                canvasX += slowIncX;
                break;
            case Event.UP:
                canvasY -= slowIncY;
                break;
            case Event.DOWN:
                canvasY += slowIncY;
                break;
            case Event.HOME:
                canvasX -= fastIncX;
                break;
            case Event.END:
                canvasX += fastIncX;
                break;
            case Event.PGUP:
                canvasY -= fastIncY;
                break;
            case Event.PGDN:
                canvasY += fastIncY;
                break;
            case '!':
                if (mapElement == null)
                    return false;
                int comp = (hotspot <= 0 || hotspot >= urls.size()) ? 1
                        : hotspot + 1;
                CgmPrimitive c = mapElement.cgm.findComponent(comp);
                if (c != null) {
                    targetURL = (URL) urls.elementAt(comp - 1);
                    double f = factor * userFactor;
                    Layer l = Layers[0];
                    canvasX = (int) Math.round((c.x + c.Width * 0.5) * f
                            * l.factorX - Width / 2);
                    canvasY = (int) Math.round((c.y + c.Height * 0.5) * f
                            * l.factorY - Height / 2);
                } else {
                    targetURL = null;
                    comp = -1;
                }
                updateHyperlink(comp, false);
                break;
            case ' ':
                userFactor = 1;
                canvasWidth = origWidth;
                canvasHeight = origHeight;
                canvasX = 0;
                canvasY = 0;
                break;
            default:
                operation = -1;
            }
            if (operation >= 0) {
                dragged = false;
                canvasWidth = (int) Math.round(origWidth * userFactor);
                canvasHeight = (int) Math.round(origHeight * userFactor);
                canvasX = Math.max(Math.min(canvasX, canvasWidth - origWidth),
                        0);
                canvasY = Math.max(
                        Math.min(canvasY, canvasHeight - origHeight), 0);
                redrawAll();
                return true;
            }
        }
        key = -k;
        notifyJS(null);
        if (ModifiersSet != 0) {
            kmod = ModifiersSet & 15;
            if (ModifierOnce)
                ModifiersSet = 0;
        }
        return true;
    }

    public boolean keyUp(Event evt, int k) {
        if ((k == -key) || (key == 0))
            key = k;
        notifyJS(null);
        return true;
    }

    private final void loadArchive(String archive) {
        if (announce)
            showStatus("Loading archive..." + archive);
        if (zipFiles == null)
            zipFiles = new Hashtable();
        try {
            URL zipfile = new URL(ImageBase, archive);
            URLConnection con = zipfile.openConnection();
            InputStream is = con.getInputStream();
            CgmContext cgm = null;
            BufferedInputStream bis = new BufferedInputStream(is);
            ZipInputStream zis = new ZipInputStream(bis);
            DataInputStream dis = new DataInputStream(zis);
            while (true) {
                ZipEntry ze = zis.getNextEntry();
                if (ze == null)
                    break;
                String fn = ze.getName().toUpperCase();
                if (fn.endsWith(".JHF")) {
                    if (this.Fonts == null)
                        this.Fonts = new Hashtable();
                    this.Fonts.put(fontname(fn), new HersheyFont(dis, fn));
                } else {
                    cgm = new CgmContext(this, fn);
                    zipFiles.put(fn, cgm);
                    cgm.getReader(dis);
                    cgm.finishReading();
                }
            }
            try {
                is.close();
            } catch (IOException e) {
            }
            return;
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    /**
     * play a sound loop
     * 
     * @param filename
     *            java.lang.String
     */
    public final void loopSound(String filename) {
        waitFor();
        getSound(filename).loop();
    }

    /**
     * use layer as image map
     * 
     * @param layer
     *            int (0..15)
     */
    public final void map(int layer) {
        getLayer(layer).visibility = STEALTH;
    }

    /**
     * use picture as image map
     * 
     * @param layer
     *            int (0..15)
     * @param filenames
     *            java.lang.String
     */
    public final void map(int layer, String filenames) {
        setAttr(layer, filenames, STEALTH);
    }

    /**
     * use conmponent for image map
     * 
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     * @param comp
     *            int
     */
    public final void map(int layer, String filename, int comp) {
        setAttr(layer, filename, comp, STEALTH);
    }

    /**
     * get mouse event
     * 
     * @return java.lang.String
     */
    public final String mouseControl() {
        String ev = AnimationEvent;
        AnimationEvent = "";
        return ev;
    }

    /**
     * get mouse event and set status bar
     * 
     * @return java.lang.String
     * @param Info
     *            java.lang.String
     */
    public final String mouseControl(String Info) {
        if (Info.length() > 0) {
            if (!Controls.equals(Info)) {
                Controls = Info;
                showStatus(Controls);
            }
        } else {
            Controls = BaseControls;
            showStatus(" ");
        }
        return mouseControl();
    }

    public boolean mouseDown(Event evt, int x, int y) {
        if (Controls.length() == 0)
            return false;

        keyMod = evt.modifiers & 15;
        if (ModifiersSet != 0) {
            keyMod = ModifiersSet & 31;
            targetURL = null;
            if (ModifierOnce)
                ModifiersSet = 0;
        }
        dragged = (keyMod == (Event.META_MASK | Event.SHIFT_MASK));
        leftmouse = (((keyMod & (Event.ALT_MASK | Event.META_MASK)) == 0) && !dragged);
        ani = (((keyMod & AnimationMask) != 0) || (AnimationMask == 0));
        mouseX = x;
        mouseY = y;
        notifyJS("Down");
        AnimationMouseX = x;
        AnimationMouseY = y;
        AnimationCurrX = x;
        AnimationCurrY = y;
        AnimationModifier = keyMod;
        if (ani) {
            AnimationClickPicture = null;
            return true;
        }
        if (BaseControls.length() == 0)
            return false;
        currX = x;
        currY = y;
        return true;
    }

    public boolean mouseDrag(Event evt, int x, int y) {
        if (((!ani) && (BaseControls.length() == 0))
                || (Controls.length() == 0))
            return false;
        dragged |= ((Math.abs(mouseX - x) * 40.0 > Width)
                || (Math.abs(mouseY - y) * 40.0 > Height) || (!leftmouse));
        if (!dragged)
            return false;
        notifyJS("Drag");
        AnimationCurrX = x;
        AnimationCurrY = y;
        if (ani) {
            AnimationDragPicture = null;
            return true;
        }
        currX = x;
        currY = y;
        if ((leftmouse) || (userFactor > 1.0))
            repaint();
        return true;
    }

    public boolean mouseEnter(Event evt, int x, int y) {
        requestFocus();
        return true;
    }

    public boolean mouseMove(Event evt, int x, int y) {
        targetURL = null;
        if (mapElement != null) {
            int comp = -1;
            double f1 = factor * userFactor;
            Layer l = getLayer(0);
            if ((l.visibility != HIDDEN) && (l.factorX >= 0.001)
                    && (l.factorY >= 0.001)) {
                double x1 = (origX - canvasX) + l.x * l.factorX;
                double y1 = (origY - canvasY) + l.y * l.factorY;
                double fx1 = f1 * l.factorX;
                double fy1 = f1 * l.factorY;
                if (mapElement.find(x1, y1, fx1, fy1, x, y)) {
                    targetURL = null;
                    comp = mapElement.SearchResult;
                    if (comp > 0) {
                        if (comp <= urls.size())
                            targetURL = (URL) urls.elementAt(comp - 1);
                        updateHyperlink(comp, true);
                        return true;
                    }
                }
            }
            updateHotspot(comp, true);
        }
        this.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
        if (Controls.length() == 0)
            return false;
        if (AnimationEvent == "") {
            notifyJS("Move");
            AnimationCurrX = x;
            AnimationCurrY = y;
            AnimationModifier = evt.modifiers & 15;
        }
        int xs = 1;
        if (!Controls.startsWith(".")) {
            int tolerance = Width / 6;
            int l = Math.max(0, Controls.length() - 15);
            xs = Math.max(0, Math.min(l, l * (x - tolerance)
                    / (Width - 2 * tolerance)));
        }
        showStatus(Controls.substring(xs));
        if ((ModifiersSet & Event.META_MASK) != 0
                & (ModifiersSet & Event.SHIFT_MASK) != 0)
            this.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return true;
    }

    public boolean mouseUp(Event evt, int x, int y) {

        if ((!ani) && (!dragged) && (targetURL != null) && (leftmouse)) {
            getAppletContext().showDocument(targetURL);
            return true;
        }
        if (((!ani) && (BaseControls.length() == 0))
                || (Controls.length() == 0))
            return false;
        try {
            double fo = userFactor;
            int cc = evt.clickCount;
            if ((keyMod & 16) != 0)
                cc = 2;
            if ((cc > 1) && (!leftmouse)) {
                userFactor = 1;
                canvasWidth = origWidth;
                canvasHeight = origHeight;
                canvasX = 0;
                canvasY = 0;
            } else {
                if (dragged) {
                    AnimationCurrX = x;
                    AnimationCurrY = y;
                    notifyJS("Drop");
                    if (!ani) {
                        if (leftmouse) {
                            userFactor = Math.min(16, fo
                                    * Math.min(Width / Math.abs(mouseX - x),
                                            Height / Math.abs(mouseY - y)));
                            canvasX = (int) Math.round((canvasX
                                    + Math.min(mouseX, x) - origX)
                                    * userFactor / fo + origX);
                            canvasY = (int) Math.round((canvasY
                                    + Math.min(mouseY, y) - origY)
                                    * userFactor / fo + origY);
                        } else {
                            canvasX = canvasX + mouseX - x;
                            canvasY = canvasY + mouseY - y;
                        }
                    }
                } else {
                    notifyJS((cc <= 1) ? "Click" : "DoubleClick");
                    if (!ani) {
                        if ((keyMod & Event.SHIFT_MASK) != 0) {
                            canvasX = (int) Math.round(canvasX + x - Width
                                    * 0.5);
                            canvasY = (int) Math.round(canvasY + y - Height
                                    * 0.5);
                        } else {
                            userFactor = (leftmouse) ? Math.min(16, userFactor
                                    * zoomFactor) : Math.max(1, userFactor
                                    / zoomFactor);
                            canvasX = (int) Math.round((canvasX + x - origX)
                                    * userFactor / fo - x + origX);
                            canvasY = (int) Math.round((canvasY + y - origY)
                                    * userFactor / fo - y + origY);
                        }
                    }
                }
                canvasWidth = (int) Math.round(origWidth * userFactor);
                canvasHeight = (int) Math.round(origHeight * userFactor);
                canvasX = Math.max(Math.min(canvasX, canvasWidth - origWidth),
                        0);
                canvasY = Math.max(
                        Math.min(canvasY, canvasHeight - origHeight), 0);
            }

            if (!ani)
                redrawAll();
        } finally {
            dragged = false;
            return true;
        }
    }

    /**
     * move an image component by (x,y)
     * 
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     * @param comp
     *            int (0...)
     * @param x
     *            double (0..1000)
     * @param y
     *            double (0..1000)
     */
    public final void moveComponent(int layer, String filename, int comp,
            double x, double y) {
        if (comp >= 0) {
            CgmPrimitive p = getElement(layer, filename).cgm
                    .findComponent(comp);
            if (p != null)
                p.move(x / 1000, y / 1000);
        }
    }

    /**
     * move an image pane by (x,y)
     * 
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     * @param pane
     *            int (0...)
     * @param x
     *            double (0..1000)
     * @param y
     *            double (0..1000)
     */
    public final void movePane(int layer, String filename, int pane, double x,
            double y) {
        CgmContext cgm = getElement(layer, filename).cgm;
        if ((pane >= 0) && (pane < cgm.pictures.size())) {
            CgmPicture pic = (CgmPicture) cgm.pictures.elementAt(pane);
            double xo = x / 1000;
            double yo = y / 1000;
            for (int i = 0; i < pic.PrimList.size(); i++)
                ((CgmPrimitive) pic.PrimList.elementAt(i)).move(xo, yo);
        }
    }

    private final URL normBase(String b) {
        URL nb = getDocumentBase();
        try {
            if (b != null) {
                if (!(b.endsWith("/")))
                    b = b + "/";
                nb = new URL(nb, b);
            }
        } catch (MalformedURLException e) {
            showStatus(e + "!");
            System.out.println(e);
            System.exit(1);
        }
        return nb;
    }

    /**
     * Insert the method's description here. Creation date: (11.01.01 19:51:29)
     */
    private void notifyJS(String ev) {
        try {
            JSmsg[0] = "Animation";
            if (ev == null) {
                JSmsg[1] = "Key";
                JSmsg[2] = (key < 0) ? "Down" : "Up";
            } else {
                JSmsg[1] = "Mouse";
                JSmsg[2] = ev;
                if (ani) {
                    AnimationEvent = ev;
                } else
                    JSmsg[0] = "Navigation";
            }
            if (JSwin != null)
                JSwin.call(JSmethod, JSmsg);
        } catch (Exception e) {
        }
    }

    public synchronized void paint(Graphics g) {
        if ((renderer != null) && (!renderer.isAlive())) {
            if ((dragged) && ((keyMod & Event.CTRL_MASK) == 0)) {
                int x1 = mouseX;
                int y1 = mouseY;
                int w1 = currX - x1;
                int h1 = currY - y1;
                if (w1 < 0) {
                    w1 = -w1;
                    x1 = currX;
                }
                if (h1 < 0) {
                    h1 = -h1;
                    y1 = currY;
                }
                if (leftmouse) {
                    g.drawImage(offScrImage, 0, 0, BackColor, null);
                    g.setXORMode(Color.cyan);
                    g.drawRect(x1, y1, w1, h1);
                    g.setPaintMode();
                } else {
                    int cx = Math.max(Math.min(canvasX + mouseX - currX,
                            canvasWidth - origWidth), 0);
                    int cy = Math.max(Math.min(canvasY + mouseY - currY,
                            canvasHeight - origHeight), 0);
                    int xo = canvasX - cx;
                    int yo = canvasY - cy;
                    g.translate(xo, yo);
                    g.drawImage(offScrImage, 0, 0, BackColor, null);
                    g.translate(-xo, -yo);
                }
            } else
                g.drawImage(offScrImage, 0, 0, BackColor, null);
            return;
        }
        if (splash) {
            splash = false;
            g.clearRect(0, 0, Width, Height);
            int h2 = Height / 2;
            int x = drawString(g, h2 / 10, h2, "cgm", 0, h2 / 2, Color.red, 1);
            x = drawString(g, x - h2 / 8, h2, "VA", 0, h2 / 2, Color.green, 1);
            x = drawString(g, x, h2, appletVersion, Font.ITALIC, h2 / 6,
                    Color.blue, 1);
            x = drawString(g, x, h2 + h2 / 8, "www.bdaum.de", 0, h2 / 12,
                    Color.blue, 2);
        }
    }

    /**
     * play a sound file
     * 
     * @param filename
     *            java.lang.String
     */
    public final void playSound(String filename) {
        waitFor();
        getSound(filename).play();
    }

    public final void preload(String filenames) {
        StringTokenizer st = new StringTokenizer(filenames, ",");
        while (st.hasMoreTokens()) {
            String fn = st.nextToken().toLowerCase();
            if (fn.endsWith(".zip")) {
                loadArchive(fn);
            } else if (fn.endsWith(".au")) {
                getSound(fn);
            } else if (fn.endsWith(".jhf")) {
                if (this.Fonts == null)
                    Fonts = new Hashtable();
                this.Fonts.put(fontname(fn), new HersheyFont(fn));
            } else {
                cgmFiles.put(fn, readFile(fn));
            }
        }
    }

    private final CgmContext readFile(String filename) {
        String fn = filename;
        if (fn.indexOf(".") < 0)
            fn = fn + ".cgm";
        CgmContext cgm = (CgmContext) cgmFiles.get(fn);
        if (cgm != null)
            return cgm;
        if (zipFiles != null) {
            if ((cgm = (CgmContext) zipFiles.get(fn.toUpperCase())) != null) {
                cgm.filename = filename;
                cgmFiles.put(fn, cgm);
                return cgm;
            }
        }
        if (announce)
            showStatus("Loading picture..." + fn);
        try {
            cgmFiles.put(fn, (cgm = new CgmContext(this, filename)));
            URL cgmfile = new URL(ImageBase, fn);
            fn = fn.toLowerCase();
            if (fn.endsWith(".gif")) {
                Image img = getImage(cgmfile);
                tracker.addImage(img, 0);
                cgm.beginPic(filename);
                cgm.currpic.image(img);
                cgm.FinishedReading = true;
                return cgm;
            }
            URLConnection con = cgmfile.openConnection();
            InputStream is = con.getInputStream();
            BufferedInputStream bis = new BufferedInputStream(is);
            DataInputStream dis = new DataInputStream(bis);
            cgm.getReader(dis);
            cgm.is = is;
            return cgm;
        } catch (IOException e) {
            System.out.println(e);
            if (isActive())
                showStatus(e + "!");
            return null;
        }
    }

    private void redrawAll() {
        if ((renderer != null) && (renderer.isAlive()))
            renderer.stop();
        renderScene();
    }

    /**
     * render a scene
     */
    public final void render() {
        if (isActive())
            renderScene();
    }

    private final void renderScene() {
        Graphics g = offScrImage.getGraphics();
        showStatus("Rendering ...");
        if (BackColor != null) {
            g.setColor(BackColor);
            g.fillRect(0, 0, Width, Height);
        } else
            g.clearRect(0, 0, Width, Height);
        try {
            tracker.waitForID(0);
        } catch (InterruptedException e) {
            return;
        }
        if (mapElement != null) {
            if (showHotspots && mapElement.visibility != Visibility.TRANSPARENT) {
                mapElement.visibility = Visibility.TRANSPARENT;
                CgmContext cgm = mapElement.cgm;
                if (cgm != null) {
                    cgm.finishReading();
                    for (int i = 0;; i++) {
                        CgmPrimitive comp = cgm.findComponent(i);
                        if (comp == null)
                            break;
                        comp.visibility = Visibility.STEALTH;
                    }
                }
            }
        }
        double f = factor * userFactor;
        Rectangle clip = new Rectangle((int) (clipX * factor),
                (int) (clipY * factor), (int) (clipW * factor),
                (int) (clipH * factor));
        renderer = new RenderThread(this, origX - canvasX + AnimationOffX * f,
                origY - canvasY + AnimationOffY * f, f * AnimationFactorX, f
                        * AnimationFactorY, offScrImage, Layers, clip, factor);
        renderer.run();
    }

    /**
     * replaces a text in component, applies to clones, too.
     * 
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     * @param n
     *            int (0...)
     * @param txt
     *            java.lang.String
     */
    public final void replaceText(int layer, String filename, int n, String txt) {
        getElement(layer, filename).replaceText(n, txt);
    }

    public void run() {
        waitFor();
        initCanvas();
        renderScene();
    }

    /**
     * scale scene by (mx,my)
     * 
     * @param mx
     *            double (1..16)
     * @param my
     *            double (1..16)
     */
    public final void scale(double mx, double my) {
        waitFor();
        AnimationFactorX = Math.min(Math.min(mx, 16), 1);
        AnimationFactorY = Math.min(Math.min(my, 16), 1);
    }

    /**
     * scale layer by (mx,my)
     * 
     * @param layer
     *            int (0..15)
     * @param mx
     *            double (1..16)
     * @param my
     *            double (1..16)
     */
    public final void scale(int layer, double mx, double my) {
        Layer l = getLayer(layer);
        l.factorX = Math.min(mx, 16);
        l.factorY = Math.min(my, 16);
    }

    /**
     * scale image by (mx,my)
     * 
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     * @param mx
     *            double (1..16)
     * @param my
     *            double (1..16)
     */
    public final void scale(int layer, String filename, double mx, double my) {
        LayerElement e = getElement(layer, filename);
        e.factorX = Math.min(mx, 16);
        e.factorY = Math.min(my, 16);
    }

    /**
     * scroll window within scene
     * 
     * @param x
     *            int
     * @param y
     *            int
     */
    public final void scroll(int x, int y) {
        canvasX = Math.max(Math.min(canvasX - x * canvasWidth / 1000,
                canvasWidth - origWidth), 0);
        canvasY = Math.max(Math.min(canvasY - y * canvasHeight / 1000,
                canvasHeight - origHeight), 0);

    }

    private final void setAttr(int layer, String filename, int vis) {
        StringTokenizer st = new StringTokenizer(filename, ",");
        while (st.hasMoreTokens())
            getElement(layer, st.nextToken()).visibility = vis;
    }

    private final void setAttr(int layer, String filename, int comp, int vis) {
        CgmPrimitive c = getElement(layer, filename).cgm.findComponent(comp);
        if (c != null)
            c.visibility = vis;
    }

    /**
     * set mask for animation events
     * 
     * @param mask
     *            int (0= all events, 1= Shift, 2= CTRL, 4= Meta)
     */
    public final void setEventMask(int mask) {
        AnimationMask = mask & 7;
    }

    /**
     * set modifiers for next mouse or key event
     */
    public final void setModifiers(int modi, int scope) {
        if (scope == 0) {
            ModifiersSet = 0;
            return;
        }
        ModifiersSet = (modi & 31) | 0x00008000;
        ModifierOnce = (scope == 1);
    }

    /**
     * set visible window to scene position
     * 
     * @param x -
     *            x-position
     */
    public final void setViewX(double x) {
        canvasX = (int) Math.max(Math.min(x * canvasWidth * userFactor * 0.001,
                canvasWidth * userFactor - origWidth), 0);
    }

    /**
     * set visible window to scene position
     * 
     * @param y -
     *            y-position
     */
    public final void setViewY(double y) {

        canvasY = (int) Math.max(Math.min(
                y * canvasHeight * userFactor * 0.001, canvasHeight
                        * userFactor - origHeight), 0);
    }

    /**
     * get scene position of visible window
     * 
     * @return x-position
     */
    public final double getViewX() {
        return 1000d * canvasX / (canvasWidth * userFactor);
    }

    /**
     * get scene position of visible window
     * 
     * @return y-position
     */
    public final double getViewY() {
        return 1000d * canvasY / (canvasHeight * userFactor);
    }

    /**
     * returns width of visible window as scene units
     * 
     * @return width
     */
    public final double getViewWidth() {
        return 1000d * Width / (canvasWidth * userFactor);
    }

    /**
     * returns height of visible window as scene units
     * 
     * @return height
     */
    public final double getViewHeight() {
        return 1000d * Height / (canvasHeight * userFactor);
    }

    /**
     * get current zoom factor
     */
    public final void setZoomFactor(double f) {
        zoomFactor = f;
    }

    /**
     * show layer
     * 
     * @param layer
     *            int (0..15)
     */
    public final void show(int layer) {
        getLayer(layer).visibility = SHOW;
    }

    /**
     * Show picture
     * 
     * @param layer
     *            int (0..15)
     * @param filenames
     *            java.lang.String
     */
    public final void show(int layer, String filenames) {
        setAttr(layer, filenames, SHOW);
    }

    private void showHotspot(int vis) {
        if (hotspot > 0) {
            CgmPrimitive prim = mapElement.cgm.findComponent(hotspot);
            if (prim != null)
                prim.visibility = vis;
        }
    }

    /**
     * Show picture
     * 
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     * @param comp
     *            int
     */
    public final void show(int layer, String filename, int comp) {
        setAttr(layer, filename, comp, SHOW);
    }

    public void start() {
        if ((UpdateThread != null) && (UpdateThread.isAlive()))
            UpdateThread.resume();
    }

    public void stop() {
        if ((UpdateThread != null) && (UpdateThread.isAlive()))
            UpdateThread.suspend();
    }

    /**
     * stop a sound file from playing
     * 
     * @param filename
     *            java.lang.String
     */
    public final void stopSound(String filename) {
        waitFor();
        getSound(filename).stop();
    }

    /**
     * Move scene to (x,y)
     * 
     * @param x
     *            double (0..1000)
     * @param y
     *            double (0..1000)
     */

    public final void translate(double x, double y) {
        waitFor();
        AnimationOffX = x / 1000;
        AnimationOffY = y / 1000;
    }

    /**
     * Move layer to (x,y)
     * 
     * @param layer
     *            int (0..15)
     * @param x
     *            double (0..1000)
     * @param y
     *            double (0..1000)
     */

    public final void translate(int layer, double x, double y) {
        Layer l = getLayer(layer);
        l.x = x / 1000;
        l.y = y / 1000;
    }

    /**
     * Move layer to (x,y)
     * 
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     * @param x
     *            double (0..1000)
     * @param y
     *            double (0..1000)
     */
    public final void translate(int layer, String filename, double x, double y) {
        LayerElement e = getElement(layer, filename);
        e.x = x / 1000;
        e.y = y / 1000;
    }

    public final void unload(String filenames) {
        StringTokenizer st = new StringTokenizer(filenames, ",");
        while (st.hasMoreTokens()) {
            String fn = st.nextToken().toLowerCase();
            if (fn.endsWith(".au")) {
                if (Sounds != null)
                    Sounds.remove(fn);
            } else if (fn.endsWith(".jhf")) {
                if (this.Fonts != null)
                    this.Fonts.remove(fontname(fn));
            } else {
                if (fn.indexOf(".") < 0)
                    fn = fn + ".cgm";
                if (zipFiles != null)
                    zipFiles.remove(fn.toUpperCase());
                CgmContext cgm = (CgmContext) cgmFiles.get(fn);
                if (cgm != null) {
                    cgmFiles.remove(fn);
                    for (int i = 0; i < 16; i++) {
                        Layer l = Layers[i];
                        if (l != null) {
                            for (int j = 0; j < l.Images.size(); j++) {
                                LayerElement e = (LayerElement) l.Images
                                        .elementAt(j);
                                if (e.cgm == cgm) {
                                    l.Images.removeElementAt(j);
                                    if (mapElement == e) {
                                        mapElement = null;
                                        urls = null;
                                    }
                                }
                            }

                        }
                    }

                }

            }
        }
    }

    public void update(Graphics g) {
        if (offScreenBuffer == null
                || (!(offScreenBuffer.getWidth(this) == Width && offScreenBuffer
                        .getHeight(this) == Height))) {
            offScreenBuffer = this.createImage(Width, Height);
        }
        paint(offScreenBuffer.getGraphics());
        g.drawImage(offScreenBuffer, 0, 0, this);
    }

    private void updateHotspot(int comp, boolean repaint) {
        if (showHotspots && comp != hotspot) {
            showHotspot(Visibility.STEALTH);
            hotspot = comp;
            showHotspot(Visibility.TRANSPARENT);
            if (repaint)
                redrawAll();
        }
    }

    private void updateHyperlink(int comp, boolean repaint) {
        updateHotspot(comp, repaint);
        if (targetURL != null) {
            showStatus(targetURL.toString());
            this.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            return;
        }
        showStatus("imagemap #" + comp);
    }

    public final void waitFor() {
        if (renderer != null) {
            try {
                while (renderer.isAlive()) {
                    renderer.join(250);
                }
            } catch (InterruptedException e) {
            }
        }
    }

    /**
     * show layer as wireframe
     * 
     * @param layer
     *            int (0..15)
     */
    public final void wire(int layer) {
        getLayer(layer).visibility = TRANSPARENT;
    }

    /**
     * Show picture as wireframe
     * 
     * @param layer
     *            int (0..15)
     * @param filenames
     *            java.lang.String
     */
    public final void wire(int layer, String filenames) {
        setAttr(layer, filenames, TRANSPARENT);
    }

    /**
     * Show picture as wireframe
     * 
     * @param layer
     *            int (0..15)
     * @param filename
     *            java.lang.String
     * @param comp
     *            int
     */
    public final void wire(int layer, String filename, int comp) {
        setAttr(layer, filename, comp, TRANSPARENT);
    }

    /**
     * Zoom by factor f to window center
     * 
     * @param f
     *            double (1..16)
     */
    public final void zoom(double f) {
        double fo = userFactor;
        double x = Width * 0.5;
        double y = Height * 0.5;
        userFactor = Math.min(16, Math.max(1, f));
        canvasX = (int) Math.round((canvasX + x - origX) * userFactor / fo - x
                + origX);
        canvasY = (int) Math.round((canvasY + y - origY) * userFactor / fo - y
                + origY);
        canvasWidth = (int) Math.round(origWidth * userFactor);
        canvasHeight = (int) Math.round(origHeight * userFactor);
        canvasX = Math.max(Math.min(canvasX, canvasWidth - origWidth), 0);
        canvasY = Math.max(Math.min(canvasY, canvasHeight - origHeight), 0);
    }

    /**
     * Zoom by factor f to position (x,y)
     * 
     * @param f
     *            double (1..16)
     * @param x
     *            double (0..1000)
     * @param y
     *            double (0..1000)
     */
    public final void zoom(double f, double x, double y) {
        userFactor = Math.min(16, Math.max(1, f));
        canvasWidth = (int) Math.round(origWidth * userFactor);
        canvasHeight = (int) Math.round(origHeight * userFactor);
        canvasX = (int) Math.round((x / 1000) * canvasWidth - Width / 2
                + userFactor * origX);
        canvasY = (int) Math.round((y / 1000) * canvasHeight - Height / 2
                + userFactor * origY);
        canvasX = Math.max(Math.min(canvasX, canvasWidth - origWidth), 0);
        canvasY = Math.max(Math.min(canvasY, canvasHeight - origHeight), 0);
    }
}
